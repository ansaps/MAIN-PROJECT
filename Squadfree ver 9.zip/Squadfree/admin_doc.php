<!DOCTYPE html>
<?php

include 'database.php';

?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />
  <link href="search.css" rel="stylesheet" />
    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	  <link href="color/default.css" rel="stylesheet">



</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="admin_profile.php">Home</a></li>
        <!--<li><a href="#"><input name="search" value="" id="searchText" maxlength="256" aria-label="Search query" autocomplete="off" aria-autocomplete="true" aria-controls="searchSuggestionTable" aria-expanded="false" placeholder="Search" type="text" />
          <input id="searchSubmit" onclick="onSearchSubmit(event)" title="Submit search" value="▶" type="button" /></a></li>-->

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">VIEW<b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#">DOCTOR</a></li>
            <li><a href="admin_pat.php">PATIENT</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">SPECIALIST<b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="add_specialist.php">ADD</a></li>
            <li><a href="view_specialist.php">VIEW</a></li>
          </ul>
        </li>

        <li><a href="logout.php">Logout</a></li>
      </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Section: intro -->
      <section id="intro" class="intro">

      <div class="slogan">
        <h2>WELCOME TO <span class="text_color">SQUAD</span> </h2>
        <h4>WE ARE GROUP OF GENTLEMEN MAKING AWESOME WEB WITH BOOTSTRAP</h4>
      </div>
      <div class="page-scroll">
        <a href="#doctor_details" class="btn btn-circle">
          <i class="fa fa-angle-double-down animated"></i>
        </a>
      </div>
    </section>
    <!--/Section: intro -->



<!-- Section: Register.Php -->


      <section id="doctor_details" class="home-section text-center">
        <div class="heading-about">
    			<div class="container">
    			<div class="row">
    				<div class="col-lg-8 col-lg-offset-2">
    					<div class="wow bounceInDown" data-wow-delay="0.4s">
    					<div class="section-heading">
    					<h2>DOCTOR DETAILS</h2>
    					<i class="fa fa-2x fa-angle-down"></i>

    					</div>
    					</div>
    				</div>
    			</div>
        </div>

<?php
        $results=mysqli_query($con,"SELECT  `REGID`,`name`, `gender`, `date_of_birth`, `address`, `email`, `PhoneNo`, `place` FROM `registration` WHERE `category_id`=1");
        while($row=mysqli_fetch_array($results))
        {
?>

                <table>
                  <form id="doctor_detail_form" action="admin_edit.php" method="post" role="form" class="contactForm">
                     <div class="row">
                        <div class="col-md-6">
                    <!-- will use later
                         <tr>
                              <div class="form-group">
                                <label for="name">Name</label>
                              </div>
                          </tr>
                          <tr>
                            <div class="form-group">
                                <label for="gender">Gender</label>
                            </div>
                          </tr>
                          <tr>
														<div class="form-group">
                                <label for="date_of_birth">Date_of_birth</label>
                            </div>
                          </tr>
                          <tr>
														<div class="form-group">
                                <label for="email">Email</label>
                            </div>
                          </tr>
                          <tr>
														<div class="form-group">
		                            <label for="address">Address</label>
                            </div>
                          </tr>
                          <tr>
														<div class="form-group">
		                            <label for="contact">Contact</label>
                            </div>
                          </tr>
                          <tr>
														<div class="form-group">
		                            <label for="place">Place</label>
                            </div>
                          </tr>
                        -->

                                  <td>
                                      <div class="form-group">
                                        <input type="text" name="name" class="form-control" id="name" value="<?php echo $row['name']?>" />
                                        <div class="validation"></div>
                                    </div>
                                </td>

                                  <td>
                                    <div class="form-group">
                                      <input type="text" name="gender" class="form-control" value="<?php echo $row['gender']?>"/>
   															      <div class="validation"></div>
                                    </div>
                                  </td>




                                  <td>
                                   <div class="form-group">
                                    <input type="date" name="dob" class="form-control" id="dob" value="<?php echo $row['date_of_birth']?>" />
                                    <div class="validation"></div>
                                   </div>
                                 </td>


                                  <td>
                                    <div class="form-group">
                                      <input type="email" name="mail" class="form-control" id="mail" value="<?php echo $row['email']?>" />
                                      <div class="validation"></div>
                                    </div>
                                  </td>



                                  <td>
                                    <div class="form-group">
		                                  <input type="text" class="form-control" name="address" value="<?php echo $row['address']?>"/>
		                                  <div class="validation"></div>
                                    </div>
                                  </td>


                                  <td>
                                    <div class="form-group">
		                                  <input type="tel" class="form-control" name="contact"  value="<?php echo $row['PhoneNo']?>"/>
		                                  <div class="validation"></div>
                                    </div>
                                  </td>

                                  <td>
                                    <div class="form-group">
		                                  <input type="text" class="form-control" name="place" value="<?php echo $row['place']?>" />
		                                  <div class="validation"></div>
                                    </div>
                                  </td>



                              <td>
                                <div class="form-group">
                                  <input type="hidden" name="regid" value="<?php echo $row['REGID'] ?>" />
                                  <button type="submit" class="btn btn-skin pull-right" id="btnContactUs" name="submit">Edit</button></a>
                                </div>
                              </td>

                        <!--<div class="col-md-12">
                            <button type="submit" class="btn btn-skin pull-right" id="btnContactUs" name="submit">
                                Submit</button>
                        </div>-->
                    </div>
                    </form>
                  </table>

                </div>
            </div>

         </div>

    		</div>
<?php } ?>

    	</section>


			<!-- Section: login -->








	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;SquadFREE. All rights reserved.</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
