<!DOCTYPE html>
<?php

include 'database.php';
$email=$_SESSION["email"];
$zone=date_default_timezone_set('Asia/Kolkata');

$min_date = date('Y-m-d');
$min_time = date("h:i A");
$comp_date = date("h:i A");
if(isset($_POST['back'])){
  echo "<script>document.location.href='absent_view.php';</script>";
}
	$sql1="select `REGID` as register_id from `registration` where `email`='$email'";
	$result1=mysqli_query($con,$sql1);
	$row = mysqli_fetch_array($result1);
	$register_id = $row['register_id'];


  //echo $register_id;

  $sql1="select `doc_id` as doctor_id from `doctor` where `REGID`='$register_id'";
	$result2=mysqli_query($con,$sql1);
	$row = mysqli_fetch_array($result2);
	$doctor_id = $row['doctor_id'];



?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---js--->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap1.js"></script>
<!---js--->
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />


    <!--  theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

  <!-- pop-up -->
  <link rel="stylesheet" href="css/swipebox.css">
  			<script src="js/jquery.swipebox.min.js"></script>
  			    <script type="text/javascript">
  					jQuery(function($) {
  						$(".swipebox").swipebox();
  					});
  				</script>

  <!-- pop-up -->



</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="change_password1.php">Change Password</a></li>
        <li><a href="edit_profile.php">Edit Profile</a></li>
        <li><a href="View_Appointments.php">Appointments</a></li>
        <li><a href="time_alloting.php">Set Time</a></li>
        <li><a href="logout.php">Logout</a></li>


      </ul>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>






<!-- Section: Login-Php -->
	<!-- /Section: login -->
     <center>
      <section id="leave" class="home-section text-center">
        <div class="heading-about">
    			<div class="container">
    			<div class="row">
    				<div class="col-lg-8 col-lg-offset-2">
    					<div class="wow bounceInDown" data-wow-delay="0.4s">
    					<div class="section-heading">
    					<h2>View Your Leaves</h2>
    					<i class="fa fa-2x fa-angle-down"></i>

    					</div>
    					</div>
    				</div>
    			</div>
        </div>

        <div class="container">

        <div class="row">
            <div class="col-lg-8">
                <div class="boxed-grey">
                        <form id="leave-form" name="myForm" action="" method="post">
                        <div class="row">






                            <div class="col-md-6">


                              <?php
                              $text=$_GET['id1'];
        												 $query=mysqli_query($con,"SELECT * FROM `absence` where `date` like '%$text%';");
        												 $qry=$query->num_rows;
        												 if($qry==0)
        												 {
        													 $mess = "No leave made on $text";
        													 echo "<script type='text/javascript'>alert('$mess');document.location.href='absent.php'</script>";
        												 }


        											while($rows3=mysqli_fetch_array($query))
        											{
        												$fro=$rows3['time_id_from'];
        												$to1=$rows3['time_id_to'];
        												$query1="SELECT  `time` as tim FROM `time` WHERE `time_id`='$fro'";
        												$qry1=mysqli_query($con,$query1);
        												$rows4=mysqli_fetch_array($qry1);
        												$sta=$rows4['tim'];
        												$query2="SELECT  `time` as tim FROM `time` WHERE `time_id`='$to1'";
        												$qry2=mysqli_query($con,$query2);
        												$rows5=mysqli_fetch_array($qry2);
        												$sto=$rows5['tim'];
        												?>


                              <table border=1>
                								<tr>
                									<td width="35%">

                										<input type="text" name="dates"   class="form-control" id="dates"   value="<?php echo $rows3['date'];?>" disabled="disabled" />

                									</td>
                									<td width="32%">

                										<input type="text" name="time_id_from"   class="form-control" id="time_id_from"  value="<?php if($sta==''){
                										 echo "FULLDAY";
                									 }
                									 else{
                										 echo $sta;
                									 }?>" disabled="disabled" />

                									</td>
                									<td width="32%">

                										<input type="text" name="time_id_to"   class="form-control" id="time_id_to"   value="<?php if($sto==''){
                										 echo "FULLDAY";
                									 }
                									 else{
                										 echo $sto;
                									 }?>" disabled="disabled" />

                									</td>
                								 <td>
                									 <a href="absent_confirmation.php?id=<?php echo $rows3['ab_id'];?>">&nbspDelete&nbsp</a>

                								 </td>
                							 </tr>
                						 </table>
                           <?php } ?>





                      </div>

											<div class="col-md-12">
                        <button type="submit" class="btn btn-skin pull-right" id="back" name="back">
													Back</button>


											</div>
                    </form>

                </div>
            </div>

         </div>

    		</div>
				</div>



    	</section>

   </center>
			<!-- Section: login -->

      <footer>
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-lg-12">
              <div class="wow shake" data-wow-delay="0.4s">
              <div class="page-scroll marginbot-30">
                <a href="#leave" id="totop" class="btn btn-circle">
                  <i class="fa fa-angle-double-up animated"></i>
                </a>
              </div>
              </div>

                        <div class="credits">

                            <p>DOCTOR PATIENT PORTAL</p>
                        </div>
            </div>
          </div>
        </div>
      </footer>








    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
