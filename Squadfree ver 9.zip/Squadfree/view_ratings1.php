
<?php
include 'db.php'; //database connection page

?>


                   </div>
<?php
include_once "db.php";
	?>

<head>
<style>
table {
   width:100% 
    border:1
}

th, td {
    text-align: left;
    padding: 20px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}
</style>
</head>
<body>


<center>
<table width="100%" >
  <tr><font color="black"<html>
    <head>
    <link rel="stylesheet" href="welcomestyle.css" />
<style>
p.button{
  width: 50%;
	cursor: pointer;
	background:grey;
}
div.sis3 {
  background: transparent ;
    position: absolute;
    top: 540px;
    right: 0;
    left:500px;
    width: 50%;
    height: 400px;
}</style>
        <title>users
        </title>
    </head>
    <br>
<br>
<br>
<br>
    <body>
    <h2>VIEW RATINGS</h2>

<table border=2>
  <tr>
  <th>CUSTOMER NAME</th>
    <th>COMMENTS</th>
 <th>RATING</th>
  
  </tr>
<!--<td><center><font color="black">&nbsp;Image</font></center></td>
<td><center><font color="black">&nbsp;Item name</font></center></td>
    <td><center><font color="black">&nbsp;Quantity</font></center></td>
    <td><center><font color="black">&nbsp;Cost</font></center></td>
    <td><center><font color="black">&nbsp;Total</font></center></td>
    <td><center><font color="black">&nbsp;Actions</font></center></td>
  </tr>-->
<?php
$results=mysqli_query($con,"select * from feedback1 f,registration r where f.username = r.username and status=0");
while($row=mysqli_fetch_array($results))
{

?>
<td><?php echo $row['username'];?></td>
<td><?php echo $row['msg'];?></td>
<td><?php echo $row['rat']; ?></td>



</tr>
<?php } ?>
</table>
</body>
</html>
