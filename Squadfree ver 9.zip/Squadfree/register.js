// JavaScript Document

function createCheck(){
	if(createCheckMandatory() == false){
		return false;
	}

	if(createCheckSize() == false){
		 return false;
	}

	var confirmDecision=confirm("You are going to save the data. Do you want to continue?");
	return 	confirmDecision;
}

function createCheckMandatory(){

	var createCheckMandatoryStatus=true;
	if(document.getElementsByName("name")[0].value == ""){
		document.getElementById("name").innerHTML = "This field is mandatory";
		createCheckMandatoryStatus=false;
	}

	if(document.getElementsByName("category")[0].value == ""){
		document.getElementById("category").innerHTML = "This field is mandatory";
		createCheckMandatoryStatus=false;
	}

if(document.getElementsByName("dob")[0].value == ""){
	document.getElementById("dob").innerHTML = "This field is mandatory";
	createCheckMandatoryStatus=false;
}


if(document.getElementsByName("mail")[0].value == ""){
	document.getElementById("mail").innerHTML = "This field is mandatory";
	createCheckMandatoryStatus=false;
}


if(document.getElementsByName("address")[0].value == ""){
	document.getElementById("address").innerHTML = "This field is mandatory";
	createCheckMandatoryStatus=false;
}


if(document.getElementsByName("contact")[0].value == ""){
	document.getElementById("contact").innerHTML = "This field is mandatory";
	createCheckMandatoryStatus=false;
}


if(document.getElementsByName("place")[0].value == ""){
	document.getElementById("place").innerHTML = "This field is mandatory";
	createCheckMandatoryStatus=false;
}

if(document.getElementsByName("password")[0].value == ""){
	document.getElementById("password").innerHTML = "This field is mandatory";
	createCheckMandatoryStatus=false;
}
return createCheckMandatoryStatus;
}
