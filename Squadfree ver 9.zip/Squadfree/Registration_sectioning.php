<?php
$_SESSION["email"]=$email;
$sql="SELECT `category_id` FROM `registration` WHERE `email`='$email'";
if($category_name==1){
	header('location:doctor_login.php?success=successfull');
}
else if($category_name==2){
	header('location:index.php?success=successfull');
}

 ?>
