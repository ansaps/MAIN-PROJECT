<!DOCTYPE html>
<?php
include 'database.php';
if(isset($_POST['submit']))
{


$name=$_POST["name"];

$category_name=$_POST["category"];


if(isset($_POST["gender"])) {

$Gender = $_POST["gender"];

/*mysql_query("INSERT INTO register (gender) VALUES ('".$a."'"); //for insert

mysql_query("UPDATE register SET gender = '".$a."'"); // for update & don't forget to add the WHERE clause to avoid updating every record-*/

} else {

$Gender = '';

}

$dob=$_POST["dob"];

$email=$_POST["mail"];
$sql0="select * from `registration`";
$result0=mysqli_query($con,$sql0);
while($row = mysqli_fetch_array($result0)){
  $mail=$row['email'];
  if($mail==$email){
  $mess = "This mail id exist.\\nPlease use another one";
   echo "<script type='text/javascript'>alert('$mess');document.location.href='register.php'</script>";
}
}

$address=$_POST["address"];

$contact=$_POST["contact"];

$place=$_POST["place"];


$password=$_POST["password"];
$pass=SHA1($password);

$date = date('Y-m-d H:i:s');



$sql= "select `category_id` as cid from `category` where `category_name`='$category_name'";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);
$category_id = $row['cid'];



$sql1="INSERT INTO `registration`(`category_id`, `name`, `gender`, `date_of_birth`, `address`, `email`, `PhoneNo`, `place`, `password`, `created_at`) VALUES ('$category_id','$name','$Gender','$dob','$address','$email','$contact','$place','$pass','$date')";
//echo $sql1;
$result1=mysqli_query($con,$sql1);

$sql4="INSERT INTO `login`(`email`, `category_id`, `password`, `modified_on`) VALUES ('$email',$category_id,'$pass','$date')";
$result3=mysqli_query($con,$sql4);
	//header("location:Registration_sectioning.php");


if($category_id==1){
  $_SESSION["email"]=$email;
  $_SESSION["password"]=$password;
  //header('location:second_fill_doctor.php?success=successfull');
  $mess = "You are succesfully registered.";
   echo "<script type='text/javascript'>alert('$mess');document.location.href='second_fill_doctor.php'</script>";
}
else if($category_id==2){
  $_SESSION["email"]=$email;
  $_SESSION["password"]=$password;
   $mess = "You are succesfully registered.";
   echo "<script type='text/javascript'>alert('$mess');document.location.href='user_profile.php'</script>";
  //header('location:user_profile.php?success=successfull');
}
else{
  $mess = "Some error encounterd";
  echo "<script type='text/javascript'>alert('$mess');document.location.href='register.php'</script>";
}





	}
?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---js--->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap1.js"></script>
<!---js--->
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />


    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

  <!-- pop-up -->
  <link rel="stylesheet" href="css/swipebox.css">
  			<script src="js/jquery.swipebox.min.js"></script>
  			    <script type="text/javascript">
  					jQuery(function($) {
  						$(".swipebox").swipebox();
  					});
  				</script>

  <!-- pop-up -->



</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>

    <li><a href="#register">Register</a></li>
    <li><a href="login.php">Login</a></li>

      </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>





<!-- Section: Register.Php -->


      <section id="register" class="home-section text-center">
        <div class="heading-about">
    			<div class="container">
    			<div class="row">
    				<div class="col-lg-8 col-lg-offset-2">
    					<div class="wow bounceInDown" data-wow-delay="0.4s">
    					<div class="section-heading">
    					<h2>Register</h2>
    					<i class="fa fa-2x fa-angle-down"></i>

    					</div>
    					</div>
    				</div>
    			</div>
        </div>

        <div class="container">

        <div class="row">
            <div class="col-lg-8">
                <div class="boxed-grey">

                    <form id="register-form" action="" method="post"  role="form" >
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">
                                    Name</label>
                                <input type="text" name="name"  class="form-control" id="name" placeholder="Your Name" pattern="([a-zA-Z]{3,30}\s*[a-zA-Z]{3,30})+" title="xxxxx xxxxxx" required />
                                <div class="validation"></div>
                            </div>
                            <div class="form-group">
                                <label for="category">
                                    Category</label>
                                <div class="form-group">

															  <select class="form-control" name="category" id="category" placeholder="Select your category"  pattern="[^DOCTOR$|^PATIENT$]" required />
																    <option value=""></option>
                                    <option value="doctor">DOCTOR</option>
																		<option value="patient">PATIENT</option>
																</select>
			                              <div class="validation"></div>
                                </div>
                            </div>
														<div class="form-group">
                                <label for="gender">Gender</label></br>
                                <input type="radio" name="gender" value="Female"checked>&nbsp;Female&nbsp;</input>
   															<input type="radio" name="gender"    value="Male">&nbsp;Male&nbsp;</input>
																<input type="radio" name="gender"    value="Others">&nbsp;Others</input>

                                <div class="validation"></div>
                            </div>
														<div class="form-group">
                                <label for="date_of_birth">
                                    Date_of_birth</label>
                                <input type="date" name="dob" class="form-control" max="1998-12-31"  min="1967-01-01" id="dob" placeholder="Your birth date"  pattern="^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$" title="dd/mm/yyyy" required />
                                <div class="validation"></div>
                            </div>
														<div class="form-group">
                                <label for="email">
                                   Email</label>
                                <input type="email" name="mail" class="form-control" id="mail" placeholder="Your email"  pattern="[\w-]+@([\w-]+\.)+[\w-]+" title="something@something.something" required/>
                                <div class="validation"></div>
                            </div>
												</div>
												<div class="col-md-6">
														<div class="form-group">
		                            <label for="address">
		                                Address</label>
		                            <textarea class="form-control" name="address" id="address" rows="5"  placeholder="Please write your address" pattern="\w+" required></textarea>
		                            <div class="validation"></div>
		                        </div>
														<div class="form-group">
		                            <label for="contact">
		                                Contact</label>
		                            <input type="tel" class="form-control" name="contact"  id="contact" pattern="[789]\d{9}" title="10 digits" placeholder="Your contact" required>
		                            <div class="validation"></div>
		                        </div>
														<div class="form-group">
		                            <label for="place">
		                                Place</label>
		                            <input type="text" class="form-control" name="place"  id="place"  pattern="[A-Za-z]+" placeholder="your place" required>
		                            <div class="validation"></div>
		                        </div>
														<div class="form-group">
		                            <label for="passsword">
		                                Password</label>
		                            <input type="password" class="form-control" name="password" id="password" pattern="(?=^.{8,}$)(?=.*\d)(?=.*[!@#$%^&*]+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" title="should have one or more uppercase characters,one or more lowercase characters,one or more numeric values,one or more special characters and length must be greater than or equal to 8 " placeholder="your password">
		                            <div class="validation"></div>
		                        </div>
                       </div>

                       <div class="col-md-12">
                            <button type="submit" class="btn btn-skin pull-right" id="submit" name="submit" onClick='return delete()'>
                                Submit</button>
                        </div>

                    </div>
                    </form>


                </div>
            </div>

         </div>

    		</div>

    	</section>

			<!-- Section: login -->








	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;SquadFREE. All rights reserved.</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>

	<script src="js1/validation.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
