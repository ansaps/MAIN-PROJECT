<?php
echo $dat=$_POST['val'];
//header( "Location: absent.php? date = $dat" );
?>
