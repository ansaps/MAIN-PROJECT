<!DOCTYPE html>
<?php
include 'database.php';
$email=$_SESSION["email"];
date_default_timezone_set('Asia/Kolkata');
$id=$_SESSION['doc_id'];
$min_date=date('Y-m-d');
$min_time = date("h:i A");
$comp_date = date("G:i",strtotime($min_time));
//$mer = date("a");

//echo $email;

?>


<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />
    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
        <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="user_profile.php">Profile</a></li>

        <li><a href="doctors_available.php">consult</a></li>
        <li><a href="Appointment _Made.php">Appointment Made</a></li>
        <li><a href="logout.php">Logout</a></li>


      </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>




	<!-- Section: about -->
  <section id="doctors available" class="home-section text-center">
  <div class="heading-about">
    <div class="container">
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2">
        <div class="wow bounceInDown" data-wow-delay="0.4s">
        <div class="section-heading">
        <h2>MAKE APPOINTMENT</h2>
        <i class="fa fa-2x fa-angle-down"></i>

        </div>
        </div>
      </div>
    </div>
    </div>
  </div>

  <div class="container">
    <div class="row">
      <div class="col-lg-2 col-lg-offset-5">
        <hr class="marginbot-50">
      </div>
    </div>

<?php
$sql1="SELECT * from `doctor` where `doc_id`='$id'";
$result1=mysqli_query($con,$sql1);


while($row = mysqli_fetch_array($result1))
{
?>

<form name="doctors_available" action="" method="post" >
<div class="container">
  <div class="row">
        <div class="col-md-3">
				<div class="wow bounceInUp" data-wow-delay="0.2s">
                <div class="team boxed-grey">
                    <div class="inner">
						<h5><?php
            $doc_id=$row['doc_id'];
            $sql2="select `REGID` as register_id from `doctor` where `doc_id`='$doc_id'";
            $result2=mysqli_query($con,$sql2);
            $row1 = mysqli_fetch_array($result2);
            $register_id = $row1['register_id'];

            $sql3="SELECT `name` as name FROM `registration` WHERE `REGID`='$register_id'";
            $result3=mysqli_query($con,$sql3);
            $row2 = mysqli_fetch_array($result3);
            $name = $row2['name'];
            echo $name;
            ?></h5>
                        <p class="subtitle"><?php
                        $doc_id=$row['doc_id'];
                        $sql4="select `specialization_id` as sid from `doctor` where `doc_id`='$doc_id'";
                        $result4=mysqli_query($con,$sql4);
                        $row3 = mysqli_fetch_array($result4);
                        $s_id = $row3['sid'];
                        $sql5="SELECT `Specialized_in` as sname FROM `specialization` WHERE `Specilization_id`='$s_id'";
                        $result5=mysqli_query($con,$sql5);
                        $row4 = mysqli_fetch_array($result5);
                        $sname = $row4['sname'];
                        echo $sname;?></p>
                        <div class="avatar"><img src="<?php echo $row['image'] ?>" alt="display" class="img-responsive img-circle" height="50"  width="100"/>


                          <div class="form-group">
                              <label for="date">
                                  date</label>
                              <input type="date" name="date"  min="<?php echo $min_date; ?>" class="form-control" id="date" placeholder="date"   title="it should be dd/mm/yyyy" required/>
                              <div class="validation"></div>
                          </div>
                          <div class="col-md-12">
                          <button type="submit" class="btn btn-skin pull-right" id="btnContactUs"  style="margin-top:0;color:white;background-color:#333d47;" id="vacancy" name="allot" value="vacancy">ALLOT
                          </button></div>

</div>

</div>

</div>

</div>

</div>

</div>

</div>

</form>



                        <?php

                          if(isset($_POST["allot"])){

                            $date=$_POST["date"];

                            $sql1="SELECT `REGID` as register_id from `registration` where `email`='$email'";
                            $result1=mysqli_query($con,$sql1);
                            $row = mysqli_fetch_array($result1);
                            $user_id = $row['register_id'];

                            $sql6="SELECT * FROM `appointment` WHERE `doctor_id`='$id'and `REGID`='$user_id' and `appointment_on`='$date'";
                            $result6=mysqli_query($con,$sql6);
                            $no1=$result6->num_rows;

                            if($no1>0){


                             $message = "You already made an appointment to Dr.$name on this date.\\nIf you want any change delete the appointnment on $date.";
                              echo "<script type='text/javascript'>alert('$message');</script>";
                              //header('location:Appointment.php');
                            }
                            else if($date<$min_date){
                              $message = "Please choose a date greater than or equal to $min_date.";
                               echo "<script type='text/javascript'>alert('$message');</script>";
                            }

                            else{
                              ?>

                                <?php

                                $sl="SELECT MAX(`time_id`) as tid  FROM `time_alloting` WHERE `doc_id`='$id'";
                                $res=mysqli_query($con,$sl);
                                $row = mysqli_fetch_array($res);
                                $tid = $row['tid'];

                                $sql4="SELECT  `time_alloted_from` as start FROM `time_alloting` WHERE `doc_id`='$id' and `time_id`='$tid'";
                                $result6=mysqli_query($con,$sql4);
                                $row = mysqli_fetch_array($result6);
                                $start_time = $row['start'];
                                $start1=date("G:i",strtotime($start_time));
                              //  $st=strtotime($start1);
                                //echo "start1 is $st";
                                /*$sql5="SELECT  `alloted_from` as start_meridiem FROM `time_alloting` WHERE `doc_id`='$id' and `time_id`='$tid'";
                                $result6=mysqli_query($con,$sql5);
                                $row = mysqli_fetch_array($result6);
                                $start_meridiem = $row['start_meridiem'];
                                  */
                                $sql6="SELECT  `time_alloted_to` as stop FROM `time_alloting` WHERE `doc_id`='$id' and `time_id`='$tid'";
                                $result7=mysqli_query($con,$sql6);
                                $row = mysqli_fetch_array($result7);
                                $stop_time = $row['stop'];
                                $stop1=date("G:i",strtotime($stop_time));
                              //  $sto=strtotime($stop1);
                              //  echo "stop1 is $sto ";
                              //  $ff=strtotime($comp_date);
                              //  echo "server time $ff";
                                /*$sql7="SELECT  `aloted_to` as stop_meridiem FROM `time_alloting` WHERE `doc_id`='$id' and `time_id`='$tid'";
                                $result8=mysqli_query($con,$sql7);
                                $row = mysqli_fetch_array($result8);
                                $stop_meridiem = $row['stop_meridiem'];
                                */

                                $sql8="SELECT `time_id` as beg  FROM `time` WHERE `time`='$start_time'";
                                $result9=mysqli_query($con,$sql8);
                                $row = mysqli_fetch_array($result9);
                                $beg = $row['beg'];

                                $sql9="SELECT `time_id` as last  FROM `time` WHERE `time`='$stop_time'";
                                $result10=mysqli_query($con,$sql9);
                                $row = mysqli_fetch_array($result10);
                                $last = $row['last'];

                                $i=0;
                                for($i=$beg;$i<=$last;$i++)
                                {
                                  $sql1="SELECT  `time` as tim FROM `time` WHERE `time_id`='$i'";
                                  $result1=mysqli_query($con,$sql1);
                                  $row = mysqli_fetch_array($result1);
                                  $time = $row['tim'];

                                ?>


                                 <form name="select_time" action="" method="post">
                                    <div class="container">
                                      <div class="row">
                                        <div class="col-md-3">
                                    				<div class="wow bounceInUp" data-wow-delay="0.2s">
                                                    <div class="team boxed-grey">
                                                        <div class="inner">
                                                      <table border=0px>
                                                        <tr>
                                                          <td>

                                                      <input  class="form-control" name="time" id="time" value="<?php   echo $time;//substr($time,0,5); ?>" disabled="disabled" >

                                                      </td>
                                                    <!--  <td>
                                                     <input  class="form-control" name="meridiem" id="meridiem" value="<?php //echo $merid; ?>" disabled="disabled">
                                                  </td>-->
                                                </tr>
                                              </table>

                                              <?php
                                              $tNow =strtotime($time);


                                              $sql2="SELECT `time_id` as times FROM `time` WHERE `time`='$time'";
                                              $result2=mysqli_query($con,$sql2);
                                              $row = mysqli_fetch_array($result2);
                                              $tim = $row['times'];


                                              $_SESSION['date']=$date;
                                              $_SESSION['sid']=$s_id;



                                              $sql11="SELECT *  FROM `appointment` WHERE `appointment_on`='$date' and `doctor_id`='$id' and `t_id`='$tim'";
                                              $result11=mysqli_query($con,$sql11);
                                              $row11 = mysqli_fetch_array($result11);

                                              $sql22="SELECT * FROM `absence` WHERE `date`='$date' and `doc_id`='$id' AND '$tim' BETWEEN `time_id_from` AND `time_id_to`";
                                              $result22=mysqli_query($con,$sql22);
                                              $count=$result22->num_rows;





                                          if($row11>0)
                                              {

                                              ?>

                                              <div class="col-md-12">
                                                  <button type="submit" class="btn btn-skin pull-right" id="btnContactUs"  name="submit" style="margin-top:0;color:white;background-color:#333d47;" value="booked" disabled="disabled" >BOOKED
                                                   </button>
                                              </div>
                                              <?php
                                            }
                                            else if($count>0){

                                              ?>
                                                  <div class="col-md-12">
                                                      <button type="submit" class="btn btn-skin pull-right" id="btnContactUs"  name="submit" style="margin-top:0;color:white;background-color:#333d47;" value="booked" disabled="disabled" >LEAVE
                                                       </button>
                                                  </div>
                                              <?php


                                            }



                                            else {
                                            if($tNow <= strtotime($stop1))
                                            {
                                              if($tNow <= strtotime($comp_date) and $date==$min_date)
                                              {
                                              ?>
                                              <div class="col-md-12">
                                                  <button type="submit" class="btn btn-skin pull-right" id="btnContactUs"  name="submit" style="margin-top:0;color:white;background-color:#333d47;" value="booked" disabled="disabled" >TIME OUT
                                                   </button>
                                              </div>
                                              <?php
                                            }


                                            else
                                            {
                                              //echo "hello";
                                              ?>


                                               <div class="col-md-12">

                                                   <a href="booked.php?id=<?php echo $tim ?>"     style="appearance: button;-webkit-appearance: button;-moz-appearance: button;-ms-appearance: button;-o-appearance: button;cursor: default;padding: 5px 15px;color:white;text-decoration:none;font-size:15px;background-color:#38B0DE;float: right;" >Select</a>

                                               </div>
                                             <?php }
                                           }


                                         }
                                              ?>






                                                        </div>

                                                    </div>

                                                </div>
                                                <hr>
                                        </div>


<?php }
?>



                                  </div>
                                </div>
                                </div>

                                <form>


                                  <?php

                                  }
                                  }
                                } ?>









</section>
	<!-- /Section: about -->


	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
