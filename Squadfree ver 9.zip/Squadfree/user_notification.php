<?php
include 'database.php';
$email=$_SESSION["email"];


//$sql="select * from comments ORDER BY id DESC limit 5";
//$result=mysqli_query($conn, $sql);//from notification



$sql="SELECT  `REGID` as reg FROM `registration` WHERE  `email`='$email'";
$result=mysqli_query($con,$sql);
$row1 = mysqli_fetch_array($result);
$reg_id = $row1['reg'];
 //echo $reg_id;

 $sql2="SELECT `doctor_id` FROM `medical_history` WHERE `REGID`='$reg_id'";
 $result2=mysqli_query($con,$sql2);
 $row2 = mysqli_fetch_array($result2);
 $did = $row2['doctor_id'];



$sql3="SELECT   * FROM `medical_history` WHERE `doctor_id`='$did'and  `REGID`='$reg_id' and `notification`=0 ORDER BY `med_id` DESC limit 5 " ;
$results=mysqli_query($con,$sql3);
$count=mysqli_num_rows($results);

$response='';
while($row3=mysqli_fetch_array($results))
{












               $sql="UPDATE `medical_history` SET `notification`=1 WHERE `notification`=0 and `doctor_id`='$did' and `REGID`='$reg_id'";
               $result=mysqli_query($con, $sql);//from notification

               $sql2="SELECT `REGID` as id FROM `doctor` WHERE `doc_id`='$did'";
               $result2=mysqli_query($con,$sql2);
               $row = mysqli_fetch_array($result2);
               $id = $row['id'];

							 $sql3="SELECT `name` as nam FROM `registration` WHERE `REGID`='$id'";
							 $result3=mysqli_query($con,$sql3);
							 $row = mysqli_fetch_array($result3);
							 $name = $row['nam'];












	$response = $response . "<div class='notification-time'>Your medical history is added by Dr." . $name .
	"<div class='notification-subject'> ".  "</div>" .
	"<div class='notification-comment'>  " . ".</div>" .
	"</div>";
}
if(!empty($response)) {
	print $response;
}

/*$date=$_SESSION['dates'];
$doctor=$_SESSION['doctor'];
$start=$_SESSION['start'];
$end=$_SESSION['end'];
$sq="SELECT * FROM `appointment` where `appointment_on`='$date' AND `REGID`='$reg_id' AND `doctor_id`='$doctor' AND `status`=1 AND `absent`=0 AND `t_id` BETWEEN '$start' AND '$end'";
$re=mysqli_query($con,$sq);
//$coun=$re->num_rows;
$response1='';
while($row4=mysqli_fetch_array($re))
{
               $tim=$re['t_id'];
               $appoint=$re['appoint_id'];
               $sql="UPDATE `appointment` SET `absent`=1 WHERE `absent`=0 and `status`=1 and `doctor_id`='$doctor' and `REGID`='$reg_id' AND `appointment_on`='$date' `t_id`='$tim'";
               $result=mysqli_query($con, $sql);//from notification

               $sql2="SELECT `REGID` as id FROM `doctor` WHERE `doc_id`='$doctor'";
               $result2=mysqli_query($con,$sql2);
               $row = mysqli_fetch_array($result2);
               $id = $row['id'];

							 $sql3="SELECT `name` as nam FROM `registration` WHERE `REGID`='$id'";
							 $result3=mysqli_query($con,$sql3);
							 $row = mysqli_fetch_array($result3);
							 $name = $row['nam'];

               $sql4="SELECT `time` FROM `time` WHERE `time_id`='$tim'";
               $result4=mysqli_query($con,$sql4);
               $rowss=mysqli_fetch_array($result4);
               $time=$rowss['time'];











	$response1 = $response1 . "<div class='notification-time'>Your appointment is canceled by Dr." . $name .
	"<div class='notification-subject'>on". $date . "</div>at" .
	"<div class='notification-comment'>  " . $time . ".</div>" .
	"</div>";


}
if(!empty($response1)) {
	print $response1;
  $sq5="DELETE FROM `appointment` WHERE `appoint_id`='$appoint'";
  $res=mysqli_query($con,$sq5);
}
*/

?>
