<!DOCTYPE html>
<?php   include 'database.php';
$email=$_SESSION["email"];
$reg=$_SESSION['reg'];
//echo $reg_dec=SHA1($reg);
if(isset($_POST['goButton']))
{
	$text=$_POST['txtModel'];
	$_SESSION['text']=$text;
	if($text=="")
	{

				echo "<script>if(confirm('plz enter a date')){document.location.href='doct_each_report.php'}else{document.location.href='doct_each_report.php'};</script>";
	}
	else {
		echo "<script>document.location.href='report_search.php';</script>";
	}
}

if(isset($_POST['back'])){
  echo "<script>document.location.href='patients.php';</script>";
}
//echo $email;

?>


<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />
    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

  <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
      <div class="container">
          <div class="navbar-header page-scroll">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                  <i class="fa fa-bars"></i>
              </button>
              <a class="navbar-brand" href="index.html">
                  <h1>DOCTOR PATIENT PORTAL</h1>
              </a>
          </div>

          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="profile.php">Profile</a></li>
      <li><a href="change_password1.php">Change Password</a></li>
      <li><a href="edit_profile.php">Edit Profile</a></li>
      <li><a href="View_Appointments.php">Appointments</a></li>
      <li><a href="time_alloting.php">Set Time</a></li>
      <li><a href="logout.php">Logout</a></li>


    </ul>
          <!-- /.navbar-collapse -->
      </div>
      <!-- /.container -->
  </nav>


	<!-- Section: about -->
  <section id="reports" class="home-section text-center">
  <div class="heading-about">
    <div class="container">
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2">
        <div class="wow bounceInDown" data-wow-delay="0.4s">
        <div class="section-heading">
        <h2>REPORTS</h2>
        <i class="fa fa-2x fa-angle-down"></i>

        </div>
        </div>
      </div>
    </div>
    </div>
  </div>

  <div class="container">

	<div class="row">
			<div class="col-lg-8">
					<div class="boxed-grey">
									<form id="leave-form" name="myForm" action="" method="post">
									<div class="row">

										<input class="form-control"  type="text" style="width:30%;height:5%;float:right" name="txtModel"  placeholder="yyyy-mm-dd">
										<button type="submit"  style="border-top: 1px solid #38B0DE;border-right: 1px solid #38B0DE;border-bottom: 1px solid #38B0DE;border-left: 2px solid #38B0DE;padding: 5px 15px;color:white;text-decoration:none;font-size:15px;background-color:#38B0DE;float: right;" name="goButton"> SEARCH </button>
									</br>
								</br>
								<hr>




											<div class="col-md-6">


<?php
$sql1="select `REGID` as register_id from `registration` where `email`='$email'";
	$result1=mysqli_query($con,$sql1);
	$row = mysqli_fetch_array($result1);
	$register_id = $row['register_id'];


  //echo $register_id;

  $sql2="select `doc_id` as doctor_id from `doctor` where `REGID`='$register_id'";
	$result2=mysqli_query($con,$sql2);
	$row = mysqli_fetch_array($result2);
	$doctor_id = $row['doctor_id'];

  $sql3="SELECT * FROM `medical_history` WHERE `doctor_id`='$doctor_id' AND `REGID`='$reg' ORDER BY `consulted_on` DESC";
  $result3=mysqli_query($con,$sql3);
  $count=$result3->num_rows;
  if($count==0)
  {
    $mess = "No medical reports added by you to this patient";
    echo "<script type='text/javascript'>alert('$mess');document.location.href='profile.php'</script>";
  }

?>
<?php

while($row3 = mysqli_fetch_array($result3))
{




  $sql4="SELECT `name`as name  FROM `registration` WHERE `REGID`='$reg'";
  $res4=mysqli_query($con,$sql4);
  $row4=mysqli_fetch_array($res4);
	$name=$row4['name'];
	$row3['description'];


?>

<table border=1 width="50%">
	<tr>
		<td >
     <textarea disabled="disabled" style="width:100px;height:50px;"><?php echo $name;?></textarea>
	 </td>
		<td >
			<textarea disabled="disabled" style="width:100px;height:50px;"><?php echo TRIM($row3['description']);?></textarea>
   </td>
		<td >
      <textarea disabled="disabled"  style="width:100px;height:50px;"><?php echo TRIM($row3['prescription']);?></textarea>
		</td>
		<td width="40%">
      <textarea disabled="disabled" style="width:100px;height:50px;"><?php echo $row3['consulted_on']; ?></textarea>
		</td>
	</tr>
</table>
<?php } ?>
</div>

<div class="col-md-12">
	<button type="submit" class="btn btn-skin pull-right" id="back" name="back">
		Back</button>


</div>
</form>

</div>
</div>

</div>

</div>
</div>


</section>

</center>
<!-- Section: login -->

	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#reports" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <p>DOCTOR PATIENT PORTAL</p>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
