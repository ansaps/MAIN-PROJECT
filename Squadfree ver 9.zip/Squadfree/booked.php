<?php

include 'database.php';
$id=$_SESSION['doc_id'];
$times=$_GET['id'];
$date=$_SESSION['date'];
$sid=$_SESSION['sid'];

//echo $time;
//echo $id;
  $email=$_SESSION["email"];


  $sql="select `REGID` as reg from `registration` where `email`='$email'";
	$result=mysqli_query($con,$sql);
	$row = mysqli_fetch_array($result);
	$reg_id = $row['reg'];

  /*$sql0="SELECT max(`appoint_id`) as appoint FROM `appointment` WHERE `REGID`='$reg_id'";
  $result=mysqli_query($con,$sql0);
	$row = mysqli_fetch_array($result);
	$appoint_id = $row['appoint'];
  //echo $appoint_id;

  $sql1="SELECT `appointment_on` as dates FROM `appointment` WHERE  `appoint_id`='$appoint_id'";
  $result1=mysqli_query($con,$sql1);
  $row = mysqli_fetch_array($result1);
  $dates = $row['dates'];
  //echo $dates;



  $sql2="SELECT `status` as sta FROM `appointment` WHERE  `appointment_on`='$dates' and `appoint_id`='$appoint_id'";
  $result2=mysqli_query($con,$sql2);
  $row = mysqli_fetch_array($result2);
  $stat = $row['sta'];
  echo $stat;
*/
  $sql4="SELECT  * FROM `appointment` WHERE   `appointment_on`='$date' and `t_id`='$times' and `REGID`='$reg_id'";
  $result4=mysqli_query($con,$sql4);
  $row4 = mysqli_fetch_array($result4);

  /*$sql3="SELECT  *  FROM `appointment` WHERE `t_id`='$times' and `appointment_on`='$date'";
  $result3=mysqli_query($con,$sql3);
  $row3 = mysqli_fetch_array($result3);*/
  if($row4){
    $mess = "you already made an appointment on this time to other doctor";
     echo "<script type='text/javascript'>alert('$mess');document.location.href='Allot.php?id=".$id."'</script>";
  }
  /*else if($row3){
    //echo "hello";
    //$message ="This slot is already booked.\nPlease choose another one";
    $mess = "This slot is already booked.\\nPlease choose another one";
     echo "<script type='text/javascript'>alert('$mess');document.location.href='Allot.php?id=".$id."'</script>";
     //echo "<script type='text/javascript'>redirect('Allot.php');</script


  }
  */

  else{
    //echo "else";
    $sql3="INSERT INTO `appointment`(`REGID`, `specialization_id`, `doctor_id`, `t_id`, `appointment_on`, `status`, `notification`) VALUES ('$reg_id','$sid','$id','$times','$date',0,0)";
  //echo $sql3;
  $res=mysqli_query($con,$sql3);
   $mess = "you made the appointment succesfully.";
   echo "<script type='text/javascript'>alert('$mess');document.location.href='doctors_available.php?id=".$id."'</script>";
}
/*else{
  $mess = "you already choosed a slot.";
  echo "<script type='text/javascript'>alert('$mess');document.location.href='Allot.php?id=".$id."'</script>";
}*/



/*
  if($stat==0){


     $sql3="UPDATE `appointment` SET `t_id`='$time', `status`=1  WHERE `appointment_on`='$dates'";
     //echo $sql3;
     $res=mysqli_query($con,$sql3);
     //header('location:Allot.php?id='.$id);

   }else {
     $message ="You already selected a slot.\nIf need any change delete appointment";
     echo "<script type='text/javascript'>alert('$message');</script>";
  }
//echo "after if";
//header('location:Allot.php?id='.$id);
*/
?>
