<!DOCTYPE html>
<?php   include 'database.php';
$email=$_SESSION["email"];
//echo $email;

?>


<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />
    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
        <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="user_profile.php">Profile</a></li>

        <li><a href="doctors_available.php">consult</a></li>
        <li><a href="Appointment _Made.php">Appointment Made</a></li>
        <li><a href="logout.php">Logout</a></li>


      </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>




	<!-- Section: about -->
  <section id="doctors available" class="home-section text-center">
  <div class="heading-about">
    <div class="container">
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2">
        <div class="wow bounceInDown" data-wow-delay="0.4s">
        <div class="section-heading">
        <h2>DOCTORS AVAILABLE</h2>
        <i class="fa fa-2x fa-angle-down"></i>

        </div>
        </div>
      </div>
    </div>
    </div>
  </div>

  <div class="container">
    <div class="row">
      <div class="col-lg-2 col-lg-offset-5">
        <hr class="marginbot-50">
      </div>
    </div>

<?php
$sql="SELECT `Specilization_id` as sid FROM `specialization`";
$result=mysqli_query($con,$sql);
while($row = mysqli_fetch_array($result))
{
 $i = $row['sid'];

//for($j=1;$j<=$i;$j++)
//{
$sql1="SELECT * from `doctor` WHERE  `specialization_id`='$i'";
$result1=mysqli_query($con,$sql1);

$sqlr="SELECT `Specialized_in` as sname FROM `specialization` WHERE `Specilization_id`='$i'";
$resultr=mysqli_query($con,$sqlr);
$rowr = mysqli_fetch_array($resultr);
$sname1 = $rowr['sname'];
?>

<h6><?php echo $sname1; ?></h6>
<hr>
<?php
while($row = mysqli_fetch_array($result1))
{
?>

<form name="doctors_available" action="" method="post" >
<div class="container">
  <div class="row">
        <div class="col-md-3">
				<div class="wow bounceInUp" data-wow-delay="0.2s">
                <div class="team boxed-grey">
                    <div class="inner">
						<h5><?php
            $doc_id=$row['doc_id'];
            $sql2="select `REGID` as register_id from `doctor` where `doc_id`='$doc_id'";
            $result2=mysqli_query($con,$sql2);
            $row1 = mysqli_fetch_array($result2);
            $register_id = $row1['register_id'];

            $sql3="SELECT `name` as name FROM `registration` WHERE `REGID`='$register_id'";
            $result3=mysqli_query($con,$sql3);
            $row2 = mysqli_fetch_array($result3);
            $name = $row2['name'];
            echo $name;
            ?></h5>
                        <p class="subtitle"><?php
                        //$doc_id=$row1['doc_id'];
                        $sql4="select `specialization_id` as sid from `doctor` where `doc_id`='$doc_id'";
                        $result4=mysqli_query($con,$sql4);
                        $row3 = mysqli_fetch_array($result4);
                        $s_id = $row3['sid'];
                        $sql5="SELECT `Specialized_in` as sname FROM `specialization` WHERE `Specilization_id`='$s_id'";
                        $result5=mysqli_query($con,$sql5);
                        $row4 = mysqli_fetch_array($result5);
                        $sname = $row4['sname'];
                        echo $sname;?></p>
                        <div class="avatar"><img src="<?php echo $row['image'] ?>" alt="display" class="img-responsive img-circle" height="50"  width="100"/>

                        <input type="hidden" name="doc_id" id="doc_id" value="<?php echo $row['doc_id'] ?>" />


                        <?php $_SESSION['doc_id']=$row['doc_id']; ?>
                          <a href="new_allotment.php" style="appearance: button;-webkit-appearance: button;-moz-appearance: button;-ms-appearance: button;-o-appearance: button;cursor: default;padding: 5px 15px;color:white;text-decoration:none;font-size:15px;background-color:#38B0DE;float: right;">Book</a>





                        </div>

                    </div>

                </div>
                <hr>
				</div>

            </div>



			<?php
}
?>

</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
<?php
}
 ?>

</div>

</div>

</form>

    </div>

	</section>
	<!-- /Section: about -->


	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
