<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> AES-S- Ansa P S(9047)-LATERAL ENTRY</title>
    <link rel="icon" type="image/ico" href="/aesicon.ico">
    <script async="" src="https://embed.tawk.to/571e4cf765c4b2085de05435/default" charset="UTF-8" crossorigin="*"></script><script src="/js/demo/ui-alerts.js"></script>
<!--STYLESHEET-->
<!--=================================================-->
<!--Open Sans Font [ OPTIONAL ]-->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css">
<!--Bootstrap Stylesheet [ REQUIRED ]-->
<link href="/css/bootstrap.min.css" rel="stylesheet">
<!--Nifty Stylesheet [ REQUIRED ]-->
<link href="/css/nifty.min.css" rel="stylesheet">
<!--Nifty Premium Icon [ DEMONSTRATION ]-->
<link href="/css/demo/nifty-demo-icons.min.css" rel="stylesheet">
<!--Demo [ DEMONSTRATION ]-->
<link href="/css/demo/nifty-demo.min.css" rel="stylesheet"> 
<!--Switchery [ OPTIONAL ]-->
<link href="/plugins/switchery/switchery.min.css" rel="stylesheet">
<!--Bootstrap Select [ OPTIONAL ]-->
<link href="/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet">
<!--Bootstrap Tags Input [ OPTIONAL ]-->
<link href="/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.css" rel="stylesheet">
<!--Chosen [ OPTIONAL ]-->
<link href="/plugins/chosen/chosen.min.css" rel="stylesheet">
<!--noUiSlider [ OPTIONAL ]-->
<link href="/plugins/noUiSlider/nouislider.min.css" rel="stylesheet">
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<link href="/plugins/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
<!--Bootstrap Datepicker [ OPTIONAL ]-->
<link href="/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="/css/custom.css" rel="stylesheet">
<!--JAVASCRIPT-->
<!--=================================================-->
<!--Pace - Page Load Progress Par [OPTIONAL]-->
<link href="/plugins/pace/pace.min.css" rel="stylesheet">
<script src="/plugins/pace/pace.min.js"></script>
<!--jQuery [ REQUIRED ]-->
<script src="/js/jquery.min.js"></script>
<!--BootstrapJS [ RECOMMENDED ]-->
<script src="/js/bootstrap.min.js"></script>
<!--NiftyJS [ RECOMMENDED ]-->
<script src="/js/nifty.min.js"></script>
<!--=================================================-->
<!--Demo script [ DEMONSTRATION ]-->
<script src="/js/demo/nifty-demo.min.js"></script>
<!--Switchery [ OPTIONAL ]-->
<script src="/plugins/switchery/switchery.min.js"></script>
<!--Bootstrap Select [ OPTIONAL ]-->
<script src="/plugins/bootstrap-select/bootstrap-select.js"></script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->
<script src="/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
<!--Chosen [ OPTIONAL ]-->
<script src="/plugins/chosen/chosen.jquery.min.js"></script>
<!--noUiSlider [ OPTIONAL ]-->
<script src="/plugins/noUiSlider/nouislider.min.js"></script>
<!--Select2 [ OPTIONAL ]-->
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<script src="/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
<!--Bootstrap Datepicker [ OPTIONAL ]-->
<script src="/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<!--Form Component [ SAMPLE ]-->
<script src="/js/form-component.js"></script>
<!--Font Awesome [ OPTIONAL ]-->
<link href="/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<!--DataTables [ OPTIONAL ]-->
<link href="/plugins/datatables/media/css/dataTables.bootstrap.css" rel="stylesheet">
<link href="/plugins/datatables/extensions/Responsive/css/responsive.dataTables.min.css" rel="stylesheet">
<!--DataTables [ OPTIONAL ]-->
<script src="/plugins/datatables/media/js/jquery.dataTables.js"></script>
<script src="/plugins/datatables/media/js/dataTables.bootstrap.js"></script>
<script src="/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js"></script>
<link href="/plugins/css-loaders/css/css-loaders.css" rel="stylesheet">
<!--DataTables Sample [ SAMPLE ]-->
<script src="/js/demo/tables-datatables.js"></script>
<!--Ion Icons [ OPTIONAL ]-->
<link href="/plugins/ionicons/css/ionicons.min.css" rel="stylesheet">
<!--Morris.js [ OPTIONAL ]-->
<script src="/plugins/morris-js/morris.min.js"></script>
<script src="/plugins/morris-js/raphael-js/raphael.min.js"></script>
<!--Morris.js Sample [ SAMPLE ]-->
<link href="/plugins/morris-js/morris.min.css" rel="stylesheet">
<!--Animate.css [ OPTIONAL ]-->
<link href="/plugins/animate-css/animate.min.css" rel="stylesheet">
<!--Bootbox Modals [ OPTIONAL ]-->
<script src="/plugins/bootbox/bootbox.min.js"></script>
<!--Modals [ SAMPLE ]-->
<script src="/js/demo/ui-modals.js"></script>
<link href="/plugins/fullcalendar/fullcalendar.min.css" rel="stylesheet">
<link href="/plugins/fullcalendar/nifty-skin/fullcalendar-nifty.min.css" rel="stylesheet">
<script src="/plugins/fullcalendar/lib/moment.min.js"></script>
<script src="/plugins/fullcalendar/lib/jquery-ui.custom.min.js"></script>
<script src="/plugins/fullcalendar/fullcalendar.min.js"></script>
<script src="/js/demo/misc-fullcalendar.js"></script>
<link href="/premium/icon-sets/icons/solid-icons/premium-solid-icons.css" rel="stylesheet">
<link id="theme" href="/css/themes/type-d/theme-purple.min.css" rel="stylesheet">
<!--FooTable [ OPTIONAL ]-->
<script src="/plugins/fooTable/dist/footable.all.min.js"></script>
<!--FooTable Example [ SAMPLE ]-->
<script src="/js/demo/tables-footable.js"></script>
<!--FooTable [ OPTIONAL ]-->
<link href="/plugins/fooTable/css/footable.core.css" rel="stylesheet">

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/571e4cf765c4b2085de05435/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->


</head>
<body class="    pace-done"><div class="pace  pace-inactive"><div class="pace-progress" style="width: 100%;" data-progress-text="100%" data-progress="99">
  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>
<div id="container" class="effect aside-float aside-bright mainnav-lg">
    <!--NAVBAR-->
    <!--===================================================-->
    <header id="navbar">
        <div id="navbar-container" class="boxed">
            <!--Brand logo & name-->
                <!--================================-->
                 <div class="navbar-fixed">
                    <a href="/students/home.php" class="navbar-brand ">
                        <img src="/images/headder_logo.png" alt="AES Logo" class="brand-icon">
                        <div class="brand-title">
                            <span class="brand-text">Amal Jyothi</span>
                        </div>
                    </a>
                </div>
                <!--================================-->
                <!--End brand logo & name-->
            <!--Navbar Dropdown-->
            <!--================================-->
            <div class="navbar-content clearfix">
                <ul class="nav navbar-top-links pull-left">
                <!--Navigation toogle button-->
                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                    <li class="tgl-menu-btn">
                        <a class="mainnav-toggle" href="#">
                            <i class="demo-pli-view-list"></i>
                        </a>
                    </li>
                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                <!--End Navigation toogle button-->
                    <li class="dropdown">
                            <a href="#" data-toggle="dropdown" class="dropdown-toggle">
                                <i class="demo-pli-bell"></i>
                                <span class="badge badge-header badge-danger"></span>
                            </a>

                            <!--Notification dropdown menu-->
                            <div class="dropdown-menu dropdown-menu-md">
                                <div class="pad-all bord-btm">
                                    <p class="text-semibold text-main mar-no">Ajce Notifications.</p>
                                </div>
                                <div class="nano scrollable has-scrollbar" style="height: 0px;">
                                    <div class="nano-content" tabindex="0" style="right: -17px;">
                                        <ul class="head-list">


<li>
                                                <a class="media" href="https://aesajce.in/staffprofile/Notice/officeAlertsNew.php" target="_blank">
                                                    <div class="media-left">
                                                        <i class="demo-pli-file-edit icon-2x"></i>
                                                    </div>
                                                    <div class="media-body">
                                                        <h5 class="mar-no text-nowrap">View All Notifications</h5>
                                                        <small></small>
                                                    </div>
                                                </a>
                                            </li>






                                            <!-- Dropdown list-->
                                           
                                        </ul>
                                    </div>
                                <div class="nano-pane" style="display: none;"><div class="nano-slider" style="height: 20px; transform: translate(0px, 0px);"></div></div></div>

                                <!--Dropdown footer-->
                               
                            </div>
                        </li>
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <!--End notifications dropdown-->
                        <!--Mega dropdown-->
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                    <li class="mega-dropdown">
                        <a href="#" class="mega-dropdown-toggle">
                            <i class="demo-pli-layout-grid"></i>
                        </a>
                        <div class="dropdown-menu mega-dropdown-menu">
                                                            <div class="row">
                                <div class="col-sm-4 col-md-3">
                                    <!--Mega menu list-->
                                    <ul class="list-unstyled">
                                  
                                        <li>
                                            <a href="/students/Leave/applyLeave.php" class="media mar-btm">
                                                <div class="media-left">
                                                <i class="fa fa-calendar"></i>
                                                </div>
                                                <div class="media-body">
                                                <p class="text-semibold text-main mar-no">Leave</p>
                                                <small class="text-muted">Student's Leave Management</small>
                                                </div>
                                            </a>
                                        </li>
                                        
                                         <li>
                                            <a href="/students/internal.php" class="media mar-btm">
                                                <div class="media-left">
                                                <i class="demo-psi-receipt-4"></i>
                                                </div>
                                                <div class="media-body">
                                                <p class="text-semibold text-main mar-no">Internal Marks</p>
                                                <small class="text-muted">View published internal marks</small>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-sm-4 col-md-3">
                                    <!--Mega menu list-->
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="/students/currentAttendance.php" class="media mar-btm">
                                                <div class="media-left">
                                                 <i class="demo-psi-gear-2"></i>
                                                </div>
                                                <div class="media-body">
                                                <p class="text-semibold text-main mar-no">Attendance</p>
                                                <small class="text-muted">Attendance reports</small>
                                                </div>
                                            </a>
                                        </li>
                                       
                                    </ul>
                                </div>
                                
                                
<div class="col-sm-4 col-md-3">
                                    <!--Mega menu list-->
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="/students/currentMarks.php" class="media mar-btm">
                                                <div class="media-left">
                                                <i class="demo-psi-bar-chart"></i>
                                                </div>
                                                <div class="media-body">
                                                <p class="text-semibold text-main mar-no">Series Exam Marks</p>
                                                <small class="text-muted">Series &amp; Module Exam Marks</small>
                                                </div>
                                            </a>
                                        </li>
                                       
                                    </ul>
                                </div>  
                                
                                
                                
                                            <div class="col-sm-4 col-md-3">
                                    <!--Mega menu list-->
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="/students/backlogReport.php" class="media mar-btm">
                                                <div class="media-left">
                                                 <i class="fa fa-times"></i>
                                                </div>
                                                <div class="media-body">
                                                <p class="text-semibold text-main mar-no">Backlog Report</p>
                                                <small class="text-muted">Backpaper reports</small>
                                                </div>
                                            </a>
                                        </li>
                                       
                                    </ul>
                                </div>
                                <div class="col-sm-4 col-md-3">
                                    <!--Mega menu list-->
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="/students/Grievance/grievanceList.php" class="media mar-btm">
                                                <div class="media-left">
                                                    <i class="ion-edit large-icon"></i>
                                                </div>
                                                <div class="media-body">
                                                    <p class="text-semibold text-main mar-no">Grievance</p>
                                                     <small class="text-muted">Posted grievances and replies </small>
                                                </div>
                                            </a>
                                        </li>
                                       
                                    </ul>
                                </div>
                                <div class="col-sm-4 col-md-3">
                                    <!--Mega menu list-->
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="/students/Forms/feePayment.php?id=L1N3ZzRRVnVncDZrdmVmU3lVOHhHZz09" class="media mar-btm">
                                                <div class="media-left">
                                                <i class="fa fa-inr"></i>
                                                </div>
                                                <div class="media-body">
                                                <p class="text-semibold text-main mar-no">Fee Payment</p>
                                                <small class="text-muted">Online Fee Payment</small>
                                                </div>
                                            </a>
                                        </li>
                                       
                                    </ul>
                                </div>   
                            </div>
                        </div>
                    </li>
                </ul>
                <ul class="nav navbar-top-links pull-right">
                    <!--Language selector-->
                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                    
								<!--User dropdown-->
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                    <li id="dropdown-user" class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle text-right">
                            <span class="ic-user pull-right">
                                                        <img class="img-circle img-user media-object" src="/photo/students/9047AnsaPS.jpg" width="50" height="50">
                                                         
                            </span>
                            <div class="username hidden-xs">Ansa P S</div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-md dropdown-menu-right panel-default">
                                <!-- Dropdown heading  -->
                                <!--<div class="pad-all bord-btm">
                                    <p class="text-main mar-btm"><span class="text-bold">750GB</span> of 1,000GB Used</p>
                                    <div class="progress progress-sm">
                                        <div class="progress-bar" style="width: 70%;">
                                            <span class="sr-only">70%</span>
                                        </div>
                                    </div>
                                </div>-->
                                <!-- User dropdown menu -->
                            <ul class="head-list">
                                <li>
                                    <a href="/students/getStudProfile.php">
                                    <i class="demo-pli-male icon-lg icon-fw"></i> Profile
                                    </a>
                                </li>
                                <li>
                                        <a href="https://aesajce.in/students/ChangePassword.php">
                                            <i class="demo-pli-gear icon-lg icon-fw"></i> Change Password
                                        </a>
                                    </li>   
                            </ul>
                                <!-- Dropdown footer -->
                           <div class="pad-all text-right">
                                                                    <a class="btn btn-purple" href="https://aesajce.in/students/aestimeline.php?page=logout">
                                                                            <i class="demo-pli-unlock"></i> Logout
                                </a>
                            </div>
                        </div>
                    </li>
                        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                        <!--End user dropdown-->

                    <li>
                        <a href="https://aesajce.in/students/aestimeline.php" class="aside-toggle navbar-aside-icon">
                            <i class="pci-ver-dots"></i>
                        </a>
                    </li>
                </ul>
            </div>
                <!--================================-->
                <!--End Navbar Dropdown-->

        </div>
    </header>
		<!--===================================================-->
        <!--END NAVBAR-->			
	


   



    <script type="text/javascript" language="javascript">
    
    <!--Bootstrap Timepicker [ OPTIONAL ]-->
  <link href="/plugins/bootstrap-timepicker/bootstrap-timepicker.min.css" 
  rel="stylesheet">


    <!--Bootstrap Datepicker [ OPTIONAL ]-->
    <link href="/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" 
    rel="stylesheet">
<!--Bootstrap Timepicker [ OPTIONAL ]-->
    <script src="/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js">
    </script>


    <!--Bootstrap Datepicker [ OPTIONAL ]-->
    <script src="/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script type="text/javascript" language="javascript">
  function validation()
  {
      {  
    if(document.getElementById('altField').value=='')
        {
            
           
        $.niftyNoty({
            type: 'danger',
            icon: 'fa fa-warning',
            container: 'floating',
            title: 'Warning!',
            message: 'Pick atleast one date',
            closeBtn: true,
             timer: 2000,
            onShow: function() {
            }
        });       
       return false;     
    }
    else
    {
        return true;
    }
  }
  }
   $(function() {
       var i=1;
 $('#demo-dp-inline').datepicker({
     todayHighlight: true,
    multidate:true,
    inline:true,
    dateFormat: "dd/mm/yy",
    //maxPicks: 3,
    
}).on('changeDate', function() 
{
   
        $('#altField').val(
            $('#demo-dp-inline').datepicker('getFormattedDate')
           
            )
          var the_dates = $('#demo-dp-inline').datepicker('getDates');
        
          // $("#newField").text($( "#demo-dp-inline" ).datepicker('getFormattedDate' ));
            //document.write('\n');
            
           if(the_dates.length>=15)
            {
                $.niftyNoty({
                    type: 'danger',
                    icon: 'fa fa-warning',
                    container: 'floating',
                    title: 'Warning!',
                    message: 'Exceeded Limit',
                    closeBtn: true,
                    timer: 2000,
                    onShow: function() {}
                });  
              // alert("not more than 15 dates picks");
                $('#demo-dp-inline').val("").datepicker("update");
            }
            $("#newsample").empty();
            for(i=0;i<the_dates.length;i++)
            {
                var myDate = new Date(the_dates[i]);
                var m=myDate.getMonth()+ 1;
                var s=m+'-'+myDate.getDate()+'-'+myDate.getFullYear();
                 $("#date-header ul").append('<li class="list-group-item list-item-sm" style="color: #6a85d4"><b>'+s+'</b></li>');
              
            }
        
          // $("#test").show();
           //document.write("\n");
           
    });
   
   });
    
    
    
    
    
    
    
function preventBack() {
window.history.forward(1);
}
setTimeout("preventBack()", 0);

    window.onunload=function(){null};
    </script>
   		<div class="boxed">
    <!--CONTENT CONTAINER-->
<!--===================================================-->
    <div id="content-container">
        <div id="page-head">
           
             <!--Page Title-->
                    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                    <div id="page-title">
                        <h1 class="page-header text-overflow" style="float: left">Leave Apply</h1>

                       
                    </div>
                   
                    <!--End page title-->
            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
            <!--End page title-->
            <!--Breadcrumb-->
            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
            <ol class="breadcrumb">
				<li><a href="/students/home.php">Home</a></li>
			
				<li class="active">Leave Apply</li>
            </ol>
            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
            <!--End breadcrumb-->
        </div>
        <div id="page-content">
            
		        
		        <!-- =========================LEAVE APPLICATION ===============-->
		        
	
   <div class="panel">
		        <div class="panel-body"> 
		        	                     
          <table id="demo-dt-addrow1" class="table table-striped table-bordered" cellspacing="0">   
  
    
     <tbody><tr><th>RLMCA352</th> </tr> <tr><td>91.89</td></tr>    
    
    
    
</tbody></table>
<div id="studAtt" style="padding-top:10px">

</div>
</div></div>        
                    
                 
                        <div class="row">
                           <div class="col-md-5 col-lg-7">
               	
                            <div class="panel">
					            <div class="panel-heading">
					                <h3 class="panel-title"><b>Select Leave Date(s)</b></h3>
					                
					            </div> 
					             <div class="panel-body">
					               <form name="frmLeaveApply" id="frmLeaveApply" onsubmit="return validation();" method="post" action="studentApplicationDetails.php">
					                                     
					                    <ul id="demo-tasklist-upcoming" class="sortable-list tasklist list-unstyled ui-sortable">
                     <li id="demo-tasklist-1" class="task-danger  ui-sortable-handle">
                    <a>     
                    <p style="color:red">You should approach your class teacher to get it sanctioned after applying it online.</p>
                    </a>
                        
                     </li>
                 </ul>
		
    					                    <div class="row">
    					                        <div class="col-sm-6">
    					                            <div class="form-group">
    					                                <div class="table-responsive">
    					                    <div id="demo-dp-inline"><div class="datepicker datepicker-inline"><div class="datepicker-days" style=""><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">�</th><th colspan="5" class="datepicker-switch">January 2018</th><th class="next">�</th></tr><tr><th class="dow">Su</th><th class="dow">Mo</th><th class="dow">Tu</th><th class="dow">We</th><th class="dow">Th</th><th class="dow">Fr</th><th class="dow">Sa</th></tr></thead><tbody><tr><td class="old day" data-date="1514678400000">31</td><td class="active day" data-date="1514764800000">1</td><td class="day" data-date="1514851200000">2</td><td class="day" data-date="1514937600000">3</td><td class="day" data-date="1515024000000">4</td><td class="day" data-date="1515110400000">5</td><td class="day" data-date="1515196800000">6</td></tr><tr><td class="day" data-date="1515283200000">7</td><td class="day" data-date="1515369600000">8</td><td class="day" data-date="1515456000000">9</td><td class="day" data-date="1515542400000">10</td><td class="day" data-date="1515628800000">11</td><td class="day" data-date="1515715200000">12</td><td class="day" data-date="1515801600000">13</td></tr><tr><td class="day" data-date="1515888000000">14</td><td class="day" data-date="1515974400000">15</td><td class="day" data-date="1516060800000">16</td><td class="day" data-date="1516147200000">17</td><td class="day" data-date="1516233600000">18</td><td class="day" data-date="1516320000000">19</td><td class="day" data-date="1516406400000">20</td></tr><tr><td class="day" data-date="1516492800000">21</td><td class="day" data-date="1516579200000">22</td><td class="day" data-date="1516665600000">23</td><td class="day" data-date="1516752000000">24</td><td class="day" data-date="1516838400000">25</td><td class="day" data-date="1516924800000">26</td><td class="day" data-date="1517011200000">27</td></tr><tr><td class="day" data-date="1517097600000">28</td><td class="day" data-date="1517184000000">29</td><td class="day" data-date="1517270400000">30</td><td class="day" data-date="1517356800000">31</td><td class="new day" data-date="1517443200000">1</td><td class="new day" data-date="1517529600000">2</td><td class="new day" data-date="1517616000000">3</td></tr><tr><td class="new day" data-date="1517702400000">4</td><td class="new day" data-date="1517788800000">5</td><td class="new day" data-date="1517875200000">6</td><td class="new day" data-date="1517961600000">7</td><td class="new day" data-date="1518048000000">8</td><td class="new day" data-date="1518134400000">9</td><td class="new day" data-date="1518220800000">10</td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div><div class="datepicker-months" style="display: none;"><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">�</th><th colspan="5" class="datepicker-switch">2018</th><th class="next">�</th></tr></thead><tbody><tr><td colspan="7"><span class="month focused active">Jan</span><span class="month active">Feb</span><span class="month active">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div><div class="datepicker-years" style="display: none;"><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">�</th><th colspan="5" class="datepicker-switch">2010-2019</th><th class="next">�</th></tr></thead><tbody><tr><td colspan="7"><span class="year old">2009</span><span class="year">2010</span><span class="year">2011</span><span class="year">2012</span><span class="year">2013</span><span class="year">2014</span><span class="year">2015</span><span class="year">2016</span><span class="year focused">2017</span><span class="year active">2018</span><span class="year">2019</span><span class="year new">2020</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div><div class="datepicker-decades" style="display: none;"><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">�</th><th colspan="5" class="datepicker-switch">2000-2090</th><th class="next">�</th></tr></thead><tbody><tr><td colspan="7"><span class="decade old">1990</span><span class="decade">2000</span><span class="decade active focused">2010</span><span class="decade">2020</span><span class="decade">2030</span><span class="decade">2040</span><span class="decade">2050</span><span class="decade">2060</span><span class="decade">2070</span><span class="decade">2080</span><span class="decade">2090</span><span class="decade new">2100</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div><div class="datepicker-centuries" style="display: none;"><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">�</th><th colspan="5" class="datepicker-switch">2000-2900</th><th class="next">�</th></tr></thead><tbody><tr><td colspan="7"><span class="century old">1900</span><span class="century active focused">2000</span><span class="century">2100</span><span class="century">2200</span><span class="century">2300</span><span class="century">2400</span><span class="century">2500</span><span class="century">2600</span><span class="century">2700</span><span class="century">2800</span><span class="century">2900</span><span class="century new">3000</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div></div></div>
    					                            </div>
    					                            </div>
    					                        </div>
    					                        <div class="col-sm-6">
    					                            <div class="list-group">
    					                                
    					                                <p class="list-group-item  list-item-sm active" href="#">Selected dates
    					                                </p><div id="date-header">
                                                             <ul class="list-group" id="newsample"><li class="list-group-item list-item-sm" style="color: #6a85d4"><b>2-24-2018</b></li><li class="list-group-item list-item-sm" style="color: #6a85d4"><b>2-25-2018</b></li><li class="list-group-item list-item-sm" style="color: #6a85d4"><b>2-26-2018</b></li><li class="list-group-item list-item-sm" style="color: #6a85d4"><b>2-27-2018</b></li><li class="list-group-item list-item-sm" style="color: #6a85d4"><b>2-28-2018</b></li><li class="list-group-item list-item-sm" style="color: #6a85d4"><b>3-1-2018</b></li><li class="list-group-item list-item-sm" style="color: #6a85d4"><b>3-29-2018</b></li><li class="list-group-item list-item-sm" style="color: #6a85d4"><b>1-1-2018</b></li></ul>

                                                        </div>
    					                            </div>
    					                        </div>
    					                      
    					                    </div>
    					                    <div class="text-right"> <input id="altField" name="dates" value="02/24/2018,02/25/2018,02/26/2018,02/27/2018,02/28/2018,03/01/2018,03/29/2018,01/01/2018" type="hidden">
    					                         <button class="btn btn-success" type="submit">Continue..</button>
    					                    </div>
    			                           
    			               </form>             
					                   
              </div>           
                         </div> 
                      
       
            <p></p>        
        	</div>
        <div class="col-md-4 col-lg-3">
					        <div class="panel">
					            <div class="panel-heading">
					                <h3 class="panel-title"><b>Leave History</b></h3>
					            </div>
					            <div class="panel-body">
					                
					                <div class="table-responsive">
					                    <table class="table table-bordered">
					                        <thead>
					                            <tr>
					                              
					                                
					                            </tr>
					                        </thead>
					                        <tbody>
					                             					       <tr>
					    <td>Attendance(%)
	</td>
					      <td>
                                    91.89                               </td>
					                           </tr>
					                            					       <tr>
					    <td>Leaves Taken</td>
					      <td>
                                    <a href="leaveApplnstatus.php">  <font style="color:black "> 5.5</font></a>                                </td>
					                           </tr>
					                            					       
					                            					                        </tbody>
					                    </table>
					                </div>  
					              
					
					               
					
					
					            </div>
					        </div>
					    </div>
        	
                
            </div>
            
            
   

		        
		        <!--=============================END===========================-->
		        
		        
		        
		        </div>
		        </div>
		        
		        </div>
		            <div id="demo-sm-modalapplication" class="modal fade" tabindex="-1">
        <div class="modal-dialog" id="leave_detete">
           <div class="modal-content" id="application">
                <!--Modal header-->
           
            </div>
        </div>
   </div>
        

 <!--MAIN NAVIGATION-->
<!--===================================================-->
<nav id="mainnav-container">
    <div id="mainnav">
        <!--Menu-->
        <!--================================-->
        <div id="mainnav-menu-wrap">
            <div class="nano has-scrollbar">
                <div class="nano-content" tabindex="0" style="right: -17px;">
                    <!--Profile Widget-->
                    <!--================================-->
                        <div id="mainnav-shortcut">
                            <ul class="list-unstyled shortcut-wrap">
                                <li class="col-xs-3" data-content="Home" data-original-title="" title="">
                                    <a class="shortcut-grid" href="../home.php">
                                        <div class="icon-wrap icon-wrap-sm icon-circle bg-trans-dark">
                                            <i class="fa fa-address-card"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="col-xs-3" data-content="Leave" data-original-title="" title="">
                                    <a class="shortcut-grid" href="/students/Leave/applyLeave.php">
                                        <div class="icon-wrap icon-wrap-sm icon-circle bg-trans-dark">
                                            <i class="fa fa-calendar-check-o"></i>
                                        </div>
                                    </a>
                                </li>						
                                <li class="col-xs-3" data-content="Academics" data-original-title="" title="">
                                    <a class="shortcut-grid" href="/students/getStudProfile.php">
                                        <div class="icon-wrap icon-wrap-sm icon-circle bg-trans-dark">
                                            <i class="ion-university"></i>
                                        </div>
                                    </a>
                               </li>
				<li class="col-xs-3" data-content="Course Related" data-original-title="" title="">
                                    <a class="shortcut-grid" href="/students/coursePlan.php">
                                        <div class="icon-wrap icon-wrap-sm icon-circle bg-trans-dark">
                                            <i class="ion-ribbon-b"></i>
                                        </div>
                                    </a>
                                </li>
				<li class="col-xs-3" data-content="Office" data-original-title="" title="">
                                    <a class="shortcut-grid" href="/students/Forms/applicationMaster.php">
                                        <div class="icon-wrap icon-wrap-sm icon-circle bg-trans-dark">
                                            <i class="fa fa-pencil"></i>
                                        </div>
                                    </a>
                                </li>
              <!--  <li class="col-xs-3" data-content="Course Diary">
                                    <a class="shortcut-grid" href="/students/coursediary/index.php">
                                        <div class="icon-wrap icon-wrap-sm icon-circle bg-trans-dark">
                                            <i class="fa fa-plus"></i>
                                        </div>
                                    </a>
                                </li>-->
				<li class="col-xs-3" data-content="Fee Payment" data-original-title="" title="">
                                    <a class="shortcut-grid" href="/students/Forms/feePayment.php?id=L1N3ZzRRVnVncDZrdmVmU3lVOHhHZz09">
                                        <div class="icon-wrap icon-wrap-sm icon-circle bg-trans-dark">
                                            <i class="fa fa-handshake-o"></i>
                                        </div>
                                    </a>
                                </li>
		
				<li class="col-xs-3" data-content="My Account" data-original-title="" title="">
                                    <a href="/students/ChangePassword.php" class="shortcut-grid">
                                        <div class="icon-wrap icon-wrap-sm icon-circle bg-trans-dark">
                                            <i class="fa fa-external-link"></i>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <ul id="mainnav-menu" class="list-group">
				  <!--Category name-->
		<li class="list-header">My Profile</li>
		<li>
		<!--Menu list item-->
	
		<a href="/students/home.php">
		<i class="demo-psi-home"></i>
		<span class="menu-title">Home</span>
		</a>
		</li>
		
		
			

					<li>
						                <a href="index.php">
						                    <i class="fa fa-graduation-cap"></i>
						                    <span class="menu-title">Academics</span><i class="arrow"></i>
						                </a>
		
		<!--Menu list item-->
	
						
		<!--Submenu-->
		<ul class="collapse" aria-expanded="false">
		 <li><a href="/students/getStudProfile.php">
		     <i class="fa fa-address-book-o"></i><span class="menu-title">My Profile</span></a></li>   
		<li><a href="/students/currentAttendance.php">
		    <i class="fa fa-calendar-check-o"></i><span class="menu-title">Attendance</span></a></li>
		
		<li><a href="/students/currentMarks.php">
		    <i class="demo-psi-bar-chart"></i><span class="menu-title">Series Exam results</span></a></li>
		
		
		<li><a href="/students/internal.php">
		    <i class="demo-psi-receipt-4"></i><span class="menu-title">Internal Mark</span></a></li>
		
		
		<li><a href="https://aesajce.in/staffprofile/Notice/officeAlertsNew.php" target="_blank"><i class="demo-pli-bell"></i>Office Alerts</a></li>	
	
		<li><a href="/students/backlogReport.php">
		    <i class="fa fa-times"></i><span class="menu-title">Backlog Report</span></a></li>
		
		<li><a href="/students/detailsMoodle.php">
		    <i class="demo-psi-lock-2"></i><span class="menu-title">Aptitude Login Details</span></a></li>
					
		</ul>
		</li>
                <!--Menu list item-->
		<li>
		<a href="#">
		<i class="fa fa-calendar"></i>
		<span class="menu-title">Leave</span>
		<i class="arrow"></i>
		</a>				
		<!--Submenu-->
		<ul class="collapse" aria-expanded="false">
		<li><a href="/students/Leave/applyLeave.php">Apply Leave</a></li>
		<li><a href="/students/Leave/leaveApplnstatus.php">View Leave Status</a></li>			
		</ul>
		</li>
	        <!--Menu list item-->
		<li>
		<a href="#">
		<i class="fa fa-book"></i>
		<span class="menu-title">Course Related</span>
		<i class="arrow"></i>
		</a>				
		<!--Submenu-->
		<ul class="collapse" aria-expanded="false">
		<li><a href="/students/coursePlan.php">Course Plan</a></li>
		<li><a href="/students/courseCoverage.php">Course Coverage</a></li>	
                <li><a href="/students/Feedback/FeedbackInstructions.php">Faculty Feedback</a></li>
		</ul>
		</li>
		           <li>
		<a href="">
		<i class="fa fa-dollar"></i>
		<span class="menu-title">Office</span><i class="arrow"></i>
		</a>
		 <!--Submenu-->
    		<ul class="collapse" aria-expanded="false">
                <li>
                    <a href="/students/Forms/applicationMaster.php">
                    <span class="menu-title">New Request</span></a></li> 
                
                
                <li>
                    <a href="/students/Forms/viewStatus.php">
                     <span class="menu-title">View Status</span></a></li>
                     
               	
    		</ul>
		</li>      
                <!--Menu list item-->
                <li>
		<a href="">
		<i class="fa fa-inr"></i>
		<span class="menu-title">Fee Payment</span><i class="arrow"></i>
		</a>
		 <!--Submenu-->
    		<ul class="collapse" aria-expanded="false">
                <li>
                    <a href="/students/Forms/feePayment.php?id=L1N3ZzRRVnVncDZrdmVmU3lVOHhHZz09">
                    <span class="menu-title">Semester Fee</span></a></li> 
                
                
                <li>
                    <a href="/students/Forms/feePayment.php?id=WWQwcjd0Mzl6ais2M2ZRRE1wRXB3UT09">
                     <span class="menu-title"> Hostel Rent</span></a></li>
                     
                <li><a href="/students/Forms/messFeePayment.php">
                    
                     <span class="menu-title">Mess Fee</span></a></li> 
                     
                     
                <li>
                    <a href="/students/Forms/vieDues.php">
                     <span class="menu-title">Online Dues</span></a></li> 
                     
                <li>
                    <a href="/students/Forms/viewdirectDues.php">
                     <span class="menu-title">Office Dues</span></a></li>
        
                <li>
                    <a href="/students/Forms/viewLibraryDues.php">
                     <span class="menu-title">Library Dues</span></a></li>
                     
                <li>
                    <a href="/students/Forms/consolidatedReport.php">
                     <span class="menu-title">Consolidated Report</span></a></li>			
    		</ul>
		</li>
	               <li>
						                <a href="/students/Grievance/grievanceList.php">
						                    <i class="fa fa-pencil"></i>
						                    <span class="menu-title">Grievance</span>
						                </a></li>
						                
						                
						                
						                     
						            <li>
						                <a href="/students/programDetails.php">
						                    <i class="fa fa-newspaper-o"></i>
						                    <span class="menu-title">Program Details</span>
						                </a></li>
						            
						             <li>
						                <a href="/students/coursePattern.php">
						                    <i class="fa fa-bar-chart"></i>
						                    <span class="menu-title">Course Pattern</span>
						                </a></li>
						
						                
		
                <li>
		<a href="#">
		<i class="fa fa-address-book-o"></i>
		<span class="menu-title">My Account</span>
		<i class="arrow"></i>
		</a>
		<ul class="collapse" aria-expanded="false">
		
		<li><a href="/students/ChangePassword.php">Change Password</a></li>			
		</ul>
		<!--Submenu-->
		
		</li>
             <li>
		<a href="/students/viewAssociatedCourse.php">
		<i class="fa fa-random"></i>
		<span class="menu-title">Add-On/Minor Courses </span>
		
		</a>				
		<!--Submenu-->
	
		</li>
                <!--Menu list item-->
	
                <li class="list-divider"></li>
	                                
                </ul>
                <!--Widget-->
                <!--================================-->
             
                <!--================================-->
                <!--End widget-->
            </div>
                        <div class="nano-pane" style="display: none;"><div class="nano-slider" style="height: 842px; transform: translate(0px, 0px);"></div></div></div>
                    </div>
                    <!--================================-->
                    <!--End menu-->

                </div>
            </nav>
            <!--===================================================-->
            <!--END MAIN NAVIGATION-->



        <!-- FOOTER -->
        <!--===================================================-->
        <footer id="footer">

            <!-- Visible when footer positions are fixed -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <div class="show-fixed pad-rgt pull-right">
                You have <a href="#" class="text-main"><span class="badge badge-danger">3</span> pending action.</a>
            </div>



            <!-- Visible when footer positions are static -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <div class="hide-fixed pull-right pad-rgt">
                
            </div>



            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <!-- Remove the class "show-fixed" and "hide-fixed" to make the content always appears. -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

            <p class="pad-lft">� 2018 AES3 : Academic Enterprise Solutions Ver. 3 </p>



        </footer>
        <!--===================================================-->
        <!-- END FOOTER -->


        <!-- SCROLL PAGE BUTTON -->
        <!--===================================================-->
        <button class="scroll-top btn">
            <i class="pci-chevron chevron-up"></i>
        </button>
        <!--===================================================-->



    </div>
    <!--===================================================-->
    <!-- END OF CONTAINER -->


    




       <div id="ziS5M1D-1519488618130" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; bottom: 0px !important; left: auto !important; position: fixed !important; border: 0px none !important; min-height: 0px !important; min-width: 0px !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: auto !important; height: auto !important; display: none; z-index: 2000000000 !important; cursor: auto !important; float: none !important; right: 0px !important;" class=""><iframe id="Muy9LZb-1519488618132" src="about:blank" scrolling="no" title="chat widget" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; right: auto !important; bottom: auto !important; left: auto !important; position: static !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 320px !important; height: 360px !important; z-index: 999999 !important; cursor: auto !important; float: none !important; display: none !important;" class="" frameborder="0"></iframe><iframe id="rc07ntt-1519488618133" src="about:blank" scrolling="no" title="chat widget" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; left: auto !important; position: fixed !important; border: 0px none !important; min-height: 66px !important; min-width: 62px !important; max-height: 66px !important; max-width: 62px !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; width: 62px !important; height: 66px !important; z-index: 1000001 !important; cursor: auto !important; float: none !important; transform: rotate(0deg) translateZ(0px) !important; transform-origin: 0px center 0px !important; bottom: 10px !important; right: 15px !important; display: block !important;" class="" frameborder="0"></iframe><iframe id="T6m0FDN-1519488618134" src="about:blank" scrolling="no" title="chat widget" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; bottom: 57px !important; position: fixed !important; border: 0px none !important; min-height: 22px !important; max-height: 22px !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; height: 22px !important; display: none !important; z-index: 1000003 !important; cursor: auto !important; float: none !important; right: 15px !important; left: auto !important; width: 62px !important; max-width: 62px !important; min-width: 62px !important;" class="" frameborder="0"></iframe><div id="UycXLxX-1519488618130" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: rgb(255, 255, 255) none repeat scroll 0% 0% !important; opacity: 0 !important; top: 1px !important; bottom: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: auto !important; height: 45px !important; display: block !important; z-index: 999997 !important; cursor: move !important; float: none !important; left: 0px !important; right: 96px !important;" class=""></div><div id="E6CNtEi-1519488618130" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: 96px !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 6px !important; height: 100% !important; display: block !important; z-index: 999998 !important; cursor: w-resize !important; float: none !important;" class=""></div><div id="ex09TH9-1519488618130" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: 0px !important; bottom: auto !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 6px !important; height: 100% !important; display: block !important; z-index: 999998 !important; cursor: e-resize !important; float: none !important;" class=""></div><div id="gRZ8HoG-1519488618130" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: 0px !important; bottom: auto !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 6px !important; display: block !important; z-index: 999998 !important; cursor: n-resize !important; float: none !important;" class=""></div><div id="HO94TwK-1519488618130" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; right: 0px !important; bottom: 0px !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 6px !important; display: block !important; z-index: 999998 !important; cursor: s-resize !important; float: none !important;" class=""></div><div id="YOdXUih-1519488618130" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999998 !important; cursor: nw-resize !important; float: none !important;" class=""></div><div id="aDzOOE0-1519488618131" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: 0px !important; bottom: auto !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999998 !important; cursor: ne-resize !important; float: none !important;" class=""></div><div id="iWIBH1n-1519488618131" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; right: auto !important; bottom: 0px !important; left: 0px !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999998 !important; cursor: sw-resize !important; float: none !important;" class=""></div><div id="SoIghGw-1519488618131" style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; right: 0px !important; bottom: 0px !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999999 !important; cursor: se-resize !important; float: none !important;" class=""></div><div style="outline: medium none currentcolor !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 100% !important; display: none !important; z-index: 1000001 !important; cursor: move !important; float: left !important;" class=""></div></div><iframe src="about:blank" style="display: none !important;" title="chat widget logging"></iframe></body></html>