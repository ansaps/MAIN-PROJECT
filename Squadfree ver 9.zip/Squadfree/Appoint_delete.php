
<?php

include 'database.php';
//$email=$_REQUEST["email"];
$email=$_SESSION["email"];
$appoint_id=$_GET['id'];
//echo $email;
//echo $appoint_id;
$sql="DELETE FROM `appointment` WHERE `appoint_id`='$appoint_id'";
$result=mysqli_query($con,$sql);
$mess = "Deleted";
echo "<script type='text/javascript'>alert('$mess');document.location.href='Appointment _Made.php?'</script>";
?>
