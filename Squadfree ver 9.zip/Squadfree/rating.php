<!DOCTYPE html>
<?php
include 'database.php';
//session_start();
$email=$_SESSION["email"];


echo "<script>alert(hgfh:$email);</script>";
if(!(isset($_SESSION["email"]))){

}
?>
<?php
//$id=$_REQUEST['restid'];
//$rid2=$_SESSION["rid"];
//INSERT INTO `feedback`(`fid`, `regid`, `restid`, `rat`, `msg`, `status`) VALUES
if(isset($_POST['sub']))
{
$msg=$_POST["msg"];
$rate=$_POST["rate"];
$sql12="INSERT INTO `feedback`(`email`,  `rate`, `message`, `status`) VALUES ('$email','$rate','$msg','0')";
$result=mysqli_query($con,$sql12);
}
?>

<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">



<title>doctor patient portal</title>
<link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--js--->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap1.js"></script>
<!---js--->
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

<!-- Fonts -->
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" />

<!-- Squad theme CSS -->
<!--<link href="css/style.css" rel="stylesheet">-->
<link href="color/default.css" rel="stylesheet">





<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <!--<i class="fa fa-bars"></i>-->
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1></h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="user_profile.php">Profile</a></li>
        <li><a href="edit_user_profile.php">Edit</a></li>
        <li><a href="change_password_user.php">Change Password</a></li>
        <li><a href="doctors_available.php">consult</a></li>
          <li><a href="User_medical.php">Reports</a></li>
          <li><a href="view_ratings1.php">View Rate</a></li>
        <li><a href="Appointment _Made.php">Appointment Made</a></li>
        <li><a href="logout.php">Logout</a></li>


      </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>


<!--<div id="wrapper">
	<div id="header" class="container">

		<div id="menu">
			<ul>
				<li  class="current_page_item"><a href="view_ratings1.php" accesskey="2" title="">VIEW RATING</a></li>



			</ul>
		</div>
</div>-->




<?php


//SELECT `fid`, `regid`, `rat`, `msg`, `status` FROM `feedback` WHERE
$sql1="SELECT * FROM `feedback`"; //value querried from the table
	$res1=mysqli_query($con,$sql1);  //query executing function
	$cnt=0;
	while($fetch1=mysqli_fetch_array($res1))
	{
$cnt=$cnt+1;
$usereid=$fetch1['email'];
$sql2="SELECT * FROM `registration` WHERE `email`='$email'"; //value querried from the table
$res2=mysqli_query($con,$sql2);  //query executing function
$fetch2=mysqli_fetch_array($res2);

//$sql3="SELECT * FROM `resturant` WHERE `restid`='$id'"; //value querried from the table
//$res3=mysqli_query($con,$sql3);  //query executing function
//$fetch3=mysqli_fetch_array($res3);
//$rname=$fetch3['restnm'];
if($cnt==4)
{
	break;
}

?>



<center>
	<section id="profile" class="home-section text-center">
	<div class="heading-about">
		<div class="container">
		<div class="row">
			<div class="col-lg-8 col-lg-offset-2">
				<div class="wow bounceInDown" data-wow-delay="0.4s">
				<div class="section-heading">
				<h2></h2>
				<!--<i class="fa fa-2x fa-angle-down"></i>-->

				</div>
				</div>
			</div>
		</div>
	</div>

	<div class="container">

	<div class="row">
		<div class="col-lg-8">
				<div class="boxed-grey">

						<form id="register-form" action="" method="post"   role="form" class="contactForm">
						<div class="row">

								<div class="col-md-6">

<h2>RATE US</h2></br>
<input type="textarea" placeholder="Enter your comments" name="msg" id="msg" value="msg" style="border-radius:5px; margin-left:80%; height:10%;"><br/><br/>
<select name="rate" class="form-control" style="margin-left:80%; border-radius:5px;">
							<option style="color:red;" value=5>excellent</option>
							<option style="color:red;" value=4>very good</option>
							<option style="color:red;" value=3>good</option>
							<option style="color:red;" value=2>fair</option>
							<option style="color:red;" value=1>poor</option>
				        </select></br></br>
  <input type='submit' value='Send' name="sub" style="border-radius:5px; margin-left:80%;">
  </form>
  </center>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</section>

<section id="profile" class="home-section text-center">
<div class="heading-about">
	<div class="container">
	<div class="row">
		<div class="col-lg-8 col-lg-offset-2">
			<div class="wow bounceInDown" data-wow-delay="0.4s">
			<div class="section-heading">
			<h2></h2>
			<!--<i class="fa fa-2x fa-angle-down"></i>-->

			</div>
			</div>
		</div>
	</div>
</div>

<div class="container">

<div class="row">
	<div class="col-lg-8">
			<div class="boxed-grey">

					<form id="register-form" action="" method="post"   role="form" class="contactForm">
					<div class="row">

							<div class="col-md-6">


<div style="width:60%; height:20%; margin-left:20%; margin-top:2%;">
<input type="textarea" class="form-control" value="<?php echo $fetch1['message'] ?>" disabled style="color:green; border:none; background-color:white; width:60%; height:50%;"></br>

<?php
for($i=0;$i<$fetch1['rate'];$i++)
{
?>
<img src="img/rating.png" width=15 height=15></img>
<?php
}
?>
<input type="text" class="form-control" value="<?php echo $fetch2['email'] ?>" disabled style=" margin-left:83%; margin-top:-3%;color:red; font-size:150%; border:none; background-color:white;"></br>



<?php
}
?>
</div>

</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</section>


</div>
</body>
</html>
