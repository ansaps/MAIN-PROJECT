<?php
include 'database.php';
$absent_id=$_GET['id'];




 ?>
 <html>

<body>
  <script>
      //var txt;
      var r = confirm("DO YOU WANT TO DELETE THIS LEAVE?");
      if (r == true) {

          window.location.href = "absent_delete.php?id=<?php echo $absent_id;?>";
      } else {
                  window.location.href = "absent_view.php";
      }
      //document.getElementById("demo").innerHTML = txt;

  </script>
</body>
</html>
