<!DOCTYPE html>
<?php   include 'database.php';
$email=$_SESSION["email"];
$text=$_GET['id1'];
if(isset($_POST['back'])){
  header('Location:patients.php');
}
//echo $email;

?>


<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />
    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
			<div class="container">
					<div class="navbar-header page-scroll">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
									<i class="fa fa-bars"></i>
							</button>
							<a class="navbar-brand" href="index.html">
									<h1>DOCTOR PATIENT PORTAL</h1>
							</a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-right navbar-main-collapse">
		<ul class="nav navbar-nav">
			<li class="active"><a href="index.php">Home</a></li>
			<li><a href="profile.php">Profile</a></li>
			<li><a href="change_password1.php">Change Password</a></li>
			<li><a href="edit_profile.php">Edit Profile</a></li>
			<li><a href="View_Appointments.php">Appointments</a></li>
			<li><a href="time_alloting.php">Set Time</a></li>
			<li><a href="logout.php">Logout</a></li>


		</ul>
					<!-- /.navbar-collapse -->
			</div>
			<!-- /.container -->
	</nav>


	<!-- Section: about -->
  <section id="doctors available" class="home-section text-center">
  <div class="heading-about">
    <div class="container">
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2">
        <div class="wow bounceInDown" data-wow-delay="0.4s">
        <div class="section-heading">
        <h2>PATIENTS</h2>
        <i class="fa fa-2x fa-angle-down"></i>

        </div>
        </div>
      </div>
    </div>
    </div>
  </div>

  <div class="container">
    <div class="row">
      <div class="col-lg-2 col-lg-offset-5">
        <hr class="marginbot-50">
      </div>
    </div>

<?php
$sql1="select `REGID` as register_id from `registration` where `email`='$email'";
	$result1=mysqli_query($con,$sql1);
	$row = mysqli_fetch_array($result1);
	$register_id = $row['register_id'];


  //echo $register_id;

  $sql2="select `doc_id` as doctor_id from `doctor` where `REGID`='$register_id'";
	$result2=mysqli_query($con,$sql2);
	$row = mysqli_fetch_array($result2);
	$doctor_id = $row['doctor_id'];

  $sql3="SELECT * FROM `registration` WHERE `name` like '%$text%' OR `gender` like '%$text%'";
  $result3=mysqli_query($con,$sql3);
  $count=$result3->num_rows;
	if($count==0)
	{
		$mess = "No record like $text";
		echo "<script type='text/javascript'>alert('$mess');document.location.href='patients.php'</script>";
	}


?>


<hr>
<?php
while($row3 = mysqli_fetch_array($result3))
{
  //echo "<tr>";


  $user_reg=$row3['REGID'];
	$sq="SELECT  DISTINCT `REGID` FROM `appointment` WHERE `REGID`='$user_reg' AND `doctor_id`='$doctor_id'";
	$re=mysqli_query($con,$sq);
	$coun=$re->num_rows;
	if($coun==0)
	{
		$mess = "This patient made no appointments to you";
		echo "<script type='text/javascript'>alert('$mess');document.location.href='patients.php'</script>";
	}
	while($ro=mysqli_fetch_array($re))
	{
  $sql4="SELECT `name`, `gender`, `date_of_birth`, `address`, `PhoneNo`, `place`  FROM `registration` WHERE `name` like '%$text%' OR `gender` like '%$text%'";
  $res4=mysqli_query($con,$sql4);
  $row4=mysqli_fetch_array($res4);

?>

<form name="doctors_available" action="" method="post" >
<div class="container">
  <div class="row">
        <div class="col-md-3">
				<div class="wow bounceInUp" data-wow-delay="0.2s">
                <div class="team boxed-grey">
                    <div class="inner">
						<h5><?php echo $row4['name'];?></h5>
                        <p class="subtitle"><table>
                            <tr>
                            <td style="float:left;">
                              <b><?php echo $row4['date_of_birth'];?></b>
                            </td>
                          </tr>
                          <tr>
                            <td style="float:left;">
                              <b><?php echo $row4['gender'];?></b>
                            </td>
                          </tr>
                          <tr>
                            <td style="float:left;">
                              <b><?php echo $row4['address'];?></b>
                            </td>
                          </tr>
                          <tr>
                          <td style="float:left;">
                            <b><?php echo $row4['place'];?></b>
                          </td>
                        </tr>
                         <tr>
                          <td style="float:left;">
                          <b><?php echo $row4['PhoneNo'];?></b>
                          </td>
                        </tr>


                          </table></p>
                        <div class="avatar">

                        <!--<input type="hidden" name="doc_id" id="doc_id" value="<?php echo $row['doc_id'] ?>" />-->



												<a href="#"  style="appearance: button;-webkit-appearance: button;-moz-appearance: button;-ms-appearance: button;-o-appearance: button;cursor: default;padding: 5px 15px;color:white;text-decoration:none;font-size:15px;background-color:#38B0DE;float: left;">REPORTS</a>
											 <a href="#"  style="appearance: button;-webkit-appearance: button;-moz-appearance: button;-ms-appearance: button;-o-appearance: button;cursor: default;padding: 5px 15px;color:white;text-decoration:none;font-size:15px;background-color:#38B0DE;float: right;">APPOINTS</a>



                        </div>

                    </div>

                </div>
                <hr>
				</div>

            </div>



			<?php
}

}
 ?>


</div>

</div>
</div>

<div class="col-md-12">
	<button type="submit" class="btn btn-skin pull-right" id="back" name="back">
		Back</button>


</div>

</form>

    </div>

	</section>
	<!-- /Section: about -->


	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
