<!DOCTYPE html>
<?php

include 'database.php';

$email=$_SESSION["email"];
$zone=date_default_timezone_set('Asia/Kolkata');

$min_date = date('Y-m-d');
$min_time = date("h:i A");

$comp_date = date("h:i A");
$date=$_SESSION['dates'];



if(isset($_POST['leave'])){



//echo $date=$_GET['date'];
  $time1=$_POST["time_alloted_from"];

  //$tim1=date("G:i",strtotime($time1));
  $time2=$_POST["time_alloted_to"];
  $sq="";

	$sql1="select `REGID` as register_id from `registration` where `email`='$email'";
	$result1=mysqli_query($con,$sql1);
	$row = mysqli_fetch_array($result1);
	$register_id = $row['register_id'];


  //echo $register_id;

  $sql1="SELECT `doc_id` as doctor_id from `doctor` where `REGID`='$register_id'";//
	$result2=mysqli_query($con,$sql1);
	$row = mysqli_fetch_array($result2);
	$doctor_id = $row['doctor_id'];
  $_SESSION['doctor']=$doctor_id;
  $sql2="SELECT `time_id` as start FROM `time` WHERE `time`='$time1'";
  $result3=mysqli_query($con,$sql2);
	$rows = mysqli_fetch_array($result3);
  $start = $rows['start'];
  $_SESSION['start']=$start;

  $sql3="SELECT `time_id` as stop FROM `time` WHERE `time`='$time2'";
  $result4=mysqli_query($con,$sql3);
	$rows1 = mysqli_fetch_array($result4);
  $end = $rows1['stop'];
  $_SESSION['end']=$end;

  $sql4="SELECT COUNT(*) as coun,`ab_id` as absent  FROM `absence` WHERE `doc_id`='$doctor_id' AND `date`='$date' AND `time_id_from`='$start' AND `time_id_to`='$end'";
  $result5=mysqli_query($con,$sql4);
  $rows4=mysqli_fetch_array($result5);
  $count1=$rows4['coun'];
  $absent_id=$rows4['absent'];



  $sq="SELECT count(*) as coun  FROM `absence` WHERE  `doc_id`='$doctor_id' AND `date`='$date' AND  `time_id_from`<'$start' AND `time_id_to`>'$end'";
  $re=mysqli_query($con,$sq);
  $ro=mysqli_fetch_array($re);
  $count2=$ro['coun'];
  $sq1="SELECT count(*) as coun  FROM `absence` WHERE  `doc_id`='$doctor_id' AND `date`='$date' AND  `time_id_from`>'$start' AND `time_id_to`<'$end'";
  $re1=mysqli_query($con,$sq1);
  $ro1=mysqli_fetch_array($re1);
  $count3=$ro1['coun'];

  $query1="SELECT *  FROM `absence` WHERE  `doc_id`='$doctor_id' AND `date`='$date'";
  $qry1=mysqli_query($con,$query1);
  $count6=0;
  while($qr1=mysqli_fetch_array($qry1))
  {
    $beg=$qr1['time_id_from'];
    $last=$qr1['time_id_to'];

  if(($start>$beg AND $start<$last) OR ($end>$beg AND $end<$last))
  {
    $count6=$count6+1;
  }
}


  if($count1>0){

    $mess = "You already made a leave on $date. If need any changes delete the applied leave";
    echo "<script type='text/javascript'>alert('$mess');document.location.href='absent_confirmation.php?id=<?php echo $absent_id;  ?>'</script>";
  }
  else if($count2>0 OR $count3>0){
    $mess = "You already made a leave on in between these times.If need any changes delete the applied leave";
    echo "<script type='text/javascript'>alert('$mess');document.location.href='absent_view.php'</script>";

  }
  else if($count6>0){
    $mess = "You already made a leave  between the selected times";
    echo "<script type='text/javascript'>alert('$mess');document.location.href='absent_view.php'</script>";

  }
  else if(($start<$end OR (( $start === 0 )&&( $end === 0 ))) AND ($count1==0 OR $count2==0))
{

   //echo "entered";
  $sql5="INSERT INTO `absence`(`doc_id`, `date`, `time_id_from`, `time_id_to`) VALUES ('$doctor_id','$date','$start','$end')";

  $res=mysqli_query($con,$sql5);
  /*$sql6="SELECT * FROM `appointment` where `appointment_on`='$date' AND `t_id` BETWEEN '$start' AND '$end'";
  $res6=mysqli_query($con,$sql6);
  while($row6=mysqli_fetch_array($res6))
  {
    $sql7="INSERT INTO `appointment`(`status`) VALUES (1) WHERE  `appointment_on`='$date' AND `t_id` BETWEEN '$start' AND '$end' AND `status`=0";
    $res7=mysqli_query($con,$sql7);
  }*/
  echo "<script>document.location.href='absent.php';</script>";






}

else
{
  $mess = "There is no consultion time you specified";
  echo "<script type='text/javascript'>alert('$mess');</script>";
}
}

if(isset($_POST['back'])){
  echo "<script>document.location.href='absent.php';</script>";
}
if(isset($_POST['view'])){
  echo "<script>document.location.href='absent_view.php';</script>";
}

?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---js--->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap1.js"></script>
<!---js--->
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />


    <!--  theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

  <!-- pop-up -->
  <link rel="stylesheet" href="css/swipebox.css">
  			<script src="js/jquery.swipebox.min.js"></script>
  			    <script type="text/javascript">
  					jQuery(function($) {
  						$(".swipebox").swipebox();
  					});
  				</script>

  <!-- pop-up -->



</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="change_password1.php">Change Password</a></li>
        <li><a href="edit_profile.php">Edit Profile</a></li>
        <li><a href="View_Appointments.php">Appointments</a></li>
        <li><a href="time_alloting.php">Set Time</a></li>
        <li><a href="logout.php">Logout</a></li>


      </ul>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	<!-- Section: intro -->
    <section id="intro" class="intro">

		<div class="slogan">
			<h2>DOCTOR PATIENT <span class="text_color">PORTAL</span> </h2>
			<h4></h4>
		</div>
		<div class="page-scroll">
			<a href="#login" class="btn btn-circle">
				<i class="fa fa-angle-double-down animated"></i>
			</a>
		</div>
    </section>
	<!-- /Section: intro -->




<!-- Section: Login-Php -->
	<!-- /Section: login -->
     <center>
      <section id="leave" class="home-section text-center">
        <div class="heading-about">
    			<div class="container">
    			<div class="row">
    				<div class="col-lg-8 col-lg-offset-2">
    					<div class="wow bounceInDown" data-wow-delay="0.4s">
    					<div class="section-heading">
    					<h2>Set Time</h2>
    					<i class="fa fa-2x fa-angle-down"></i>

    					</div>
    					</div>
    				</div>
    			</div>
        </div>

        <div class="container">

        <div class="row">
            <div class="col-lg-8">
                <div class="boxed-grey">
                        <form id="leave-form" name="myForm" action="" method="post">
                        <div class="row">
                            <div class="col-md-6">
                        <input type="text" name="dates"   class="form-control" id="dates" placeholder="date"  value="<?php echo $date;?>" disabled="disabled" />



    																		<?php
                                        $sql2="SELECT `time` as id FROM `time` WHERE `time_id`=0";
                                        $result2=mysqli_query($con,$sql2);
                                      	 $row = mysqli_fetch_array($result2);
                                      	 $id = $row['id'];

                                         $sql3="SELECT `time` as id FROM `time` WHERE `time_id`=24";
                                         $result3=mysqli_query($con,$sql3);
                                       	 $row = mysqli_fetch_array($result3);
                                       	 $idn = $row['id'];
                                         //$id1=strtotime($idn);
                                         //echo "$idn is $id1";
                                         //$idn1=date("G:i",strtotime($idn));
                                         //$id2=strtotime($idn1);
                                         //echo "$idn1 is  $id2";

                                         ?>
                                         <div class="form-group">
                                             <label for="time_alloted_from">
                                                 Time_alloted_from</label>
                                                 <div class="form-group">
                                                   <table border=0px>
                                                     <tr>
                                                       <td>
                 																	<select  class="form-control" name="time_alloted_from" id="time_from">
                                                  <option value="" ></option>
                                     <?php
                                      //  echo "hello";
                                      //  echo $dates=$_POST['date1'];
    																			echo $sql="SELECT `time_id`, `time` FROM `time` where `time_id` between 1 and 24";

    																			$r=mysqli_query($con,$sql);


    																			if(mysqli_num_rows  ($r) > 0)
    																			{
                                            //echo "hello";
    																				while ($row = mysqli_fetch_assoc($r) ) {
    																					# code...
                                              $id= $row ["time_id"];
                                              $time1= $row ["time"];
                                              //$time11=date("G:i",strtotime($time1));
                                              //$tNo=date("G:i",strtotime($time1));
                                              //$time11=date("G:i",strtotime($time1));
                                              $tNow=strtotime($time1);
                                              if($tNow <= strtotime($idn) and $date==$min_date)
                                              {

                                                if($tNow <= strtotime($comp_date)){ $prop ='disabled';  }else{ $prop='';  }
                                                echo '<option value="'.$time1.'" '.$prop.'>'.$time1.'</option>';
                                              }
                                              else
                                              {
                                                echo '<option value="'.$time1.'">'.$time1.'</option>';
                                              }
    																					?>


    																					<!--<option value="'.<?php //echo $time1;?>.'" '.<?php //echo $prop; ?> .'><?php //echo $time1;?></option>-->
                                          <?php
                                           }
                                          }

                                        ?>
    																		</select>
                                      </td>

                                </tr>
                              </table>

                                    <div class="validation"></div>
                                </div>

                            </div>
                            <div class="form-group">
                                <label for="time_alloted_to">
                                    Time_alloted_to</label>
                                    <div class="form-group">
                                  <table border=0px>
                                    <tr>
                                      <td>
                                  <select  class="form-control" name="time_alloted_to" id="time_to" >
                                    <option value="" ></option>

                                    <?php
                                    //echo "hello";
                                    echo $sql="SELECT `time_id`, `time` FROM `time` where `time_id` between 1 and 24";

                                    $r=mysqli_query($con,$sql);


                                    if(mysqli_num_rows  ($r) > 0)
                                    {
                                      //echo "hello";
                                      while ($row = mysqli_fetch_assoc($r) ) {
                                        # code...
                                        $id1= $row ["time_id"];
                                        $time2= $row ["time"];
                                        //$time11=date("G:i",strtotime($time1));
                                        //$tNo=date("G:i",strtotime($time1));
                                        //$time11=date("G:i",strtotime($time1));
                                        $tNow=strtotime($time2);
                                        if($tNow <= strtotime($idn) and $date==$min_date)
                                        {

                                          if($tNow <= strtotime($comp_date)){ $prop ='disabled';  }else{ $prop='';  }
                                            echo '<option value="'.$time2.'" '.$prop.'>'.$time2.'</option>';
                                          }
                                          else
                                          {
                                            echo '<option value="'.$time2.'">'.$time2.'</option>';
                                          }

                                        }
                                      }
                                      ?>
                                    </select>
                                  </td>

                            </tr>
                          </table>

                                <div class="validation"></div>
                            </div>
                            </div>



                      </div>



                      <div class="col-md-12">
                  <!--                <a style="display: block;float: right;width: 115px;height: 34px;background:#6495ED;padding: 6px;text-align: center;border-radius: 0px;color: white;font-weight: bold;" href="absent.php">BACK</a>-->
                         <button type="submit" class="btn btn-skin pull-right" id="back" name="back">
                          Back</button>
                              <button type="submit" class="btn btn-skin pull-right" id="leave" name="leave">
                              Mark Leave</button>
                              <button type="submit" class="btn btn-skin pull-right" id="leave" name="view">
                              View Leaves</button>



                      </div>
                    </div>
                    </form>

                </div>
            </div>

         </div>

    		</div>

    	</section>
   </center>
			<!-- Section: login -->








	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#leave" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>

                    <div class="credits">

                        <p>DOCTOR PATIENT PORTAL</p>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
