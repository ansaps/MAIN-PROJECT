<!DOCTYPE html>
<?php
include 'database.php';
$email=$_SESSION["email"];
$zone=date_default_timezone_set('Asia/Kolkata');
$min_date = date('Y-m-d');
$min_time = date("h:i A");
$comp_date = date("h:i A");

if(isset($_POST['submit'])){
  $dates=$_POST["date"];
  $_SESSION['date']=$dates;
  $sql1="SELECT `REGID` as regid  FROM `registration` WHERE `email`='$email'";
  $res1=mysqli_query($con,$sql1);
  $row1=mysqli_fetch_array($res1);
  $regid=$row1['regid'];
  $sql2="SELECT `doc_id`as docid FROM `doctor` WHERE `REGID`='$regid'";
  $res2=mysqli_query($con,$sql2);
  $row2=mysqli_fetch_array($res2);
  $docid=$row2['docid'];


  $sql3="SELECT * FROM `absence` WHERE `date`='$dates' AND  `time_id_from`=0 AND `time_id_to`=0 and `doc_id`='$docid'";
  $res3=mysqli_query($con,$sql3);
  $row3=mysqli_fetch_array($res3);
  if($row3)
{
  $absent_id=$row3['ab_id'];
  $mess = "You already booked a whole day leave.If need any changes delete the leave on $dates.";
  echo "<script type='text/javascript'>alert('$mess');document.location.href='absent_confirmation.php?id=<?php echo $absent_id;  ?>'</script>";
  }
else{
  echo "<script>document.location.href='absent_apply.php';</script>";
}
}



?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---js--->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap1.js"></script>
<!---js--->
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />


    <!--  theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

  <!-- pop-up -->
  <link rel="stylesheet" href="css/swipebox.css">
  			<script src="js/jquery.swipebox.min.js"></script>
  			    <script type="text/javascript">
  					jQuery(function($) {
  						$(".swipebox").swipebox();
  					});
  				</script>

  <!-- pop-up -->

  <script type="text/javascript">
  function onSelectChange(){

   var test=document.getElementById("date").value;

   document.getElementById("date1").value = test;
   var val=document.getElementById("date1").value;
   $.ajax({
       type: "POST",
       url: 'desk.php',
       data: { val : val},
       success: function(data)
       {
           alert("sucess"+data);
           //alert( data );
       }
   });

//window.location.href="absent.php?date=test";
  }

</script>

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="change_password1.php">Change Password</a></li>
        <li><a href="edit_profile.php">Edit Profile</a></li>
        <li><a href="View_Appointments.php">Appointments</a></li>
        <li><a href="time_alloting.php">Set Time</a></li>
        <li><a href="logout.php">Logout</a></li>


      </ul>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	<!-- Section: intro -->
    <section id="intro" class="intro">

		<div class="slogan">
			<h2>DOCTOR PATIENT <span class="text_color">PORTAL</span> </h2>
			<h4></h4>
		</div>
		<div class="page-scroll">
			<a href="#login" class="btn btn-circle">
				<i class="fa fa-angle-double-down animated"></i>
			</a>
		</div>
    </section>
	<!-- /Section: intro -->




<!-- Section: Login-Php -->
	<!-- /Section: login -->
     <center>
      <section id="leave" class="home-section text-center">
        <div class="heading-about">
    			<div class="container">
    			<div class="row">
    				<div class="col-lg-8 col-lg-offset-2">
    					<div class="wow bounceInDown" data-wow-delay="0.4s">
    					<div class="section-heading">
    					<h2>APPLY LEAVE</h2>
    					<i class="fa fa-2x fa-angle-down"></i>

    					</div>
    					</div>
    				</div>
    			</div>
        </div>

        <div class="container">

        <div class="row">
            <div class="col-lg-8">
                <div class="boxed-grey">

                    <form id="login-form" name="myForm" action="" method="post">
                    <div class="row">
                        <div class="col-md-6">

                          <div class="form-group">
                              <label for="date">
                                  date</label>
                              <input type="date" name="date"  min="<?php echo $min_date; ?>" class="form-control" id="date" placeholder="date" pattern="^([0]?[0-9]|[12][0-9]|[3][01])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$"  title="it should be dd/mm/yyyy"  required/>
                              <button type="submit" class="btn btn-skin pull-right" id="btnContactUs" name="submit">
                                  Go</button>
                              <div class="validation"></div>

                          </div>

                        </div>

                      </div>
                      </form>
                      <hr>
                      <a href="absent_view.php" style="appearance: button;-webkit-appearance: button;-moz-appearance: button;-ms-appearance: button;-o-appearance: button;cursor: default;padding: 5px 15px;color:white;text-decoration:none;font-size:15px;background-color:#38B0DE;float: right;">VIEW LEAVES</a>

                </div>

            </div>

         </div>

    		</div>


    	</section>
   </center>
			<!-- Section: login -->








	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#leave" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>

                    <div class="credits">

                        <p>DOCTOR PATIENT PORTAL</p>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
