<?php
include 'database.php';
$regid=$_REQUEST['regid'];
if(isset($_POST['update']))
{

$name=$_POST["name"];
$category_name=$_POST["category"];
$dob=$_POST["dob"];
$email=$_POST["mail"];
$address=$_POST["address"];
$contact=$_POST["contact"];
$place=$_POST["place"];
$password=$_POST["password"];
echo $name;


$sql= "select `category_id` as cid from `category` where `category_name`='$category_name'";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);
$category_name1 = $row['cid'];

$sql1="UPDATE `registration` SET `category_id`='$category_name1',`name`='$name',`date_of_birth`='$dob',`address`='$address',`email`='$email',`PhoneNo`='$contact',`place`='$place',`password`='$password' WHERE `REGID`='$regid'";

$results1=mysqli_query($con,$sql1);
/*
$sql2="select `email` as mail from `registration` where `REGID`='$regid'";
$result1=mysqli_query($con,$sql2);
$row1 = mysqli_fetch_array($result1);
$mail = $row1['mail'];
*/


$sql2="UPDATE `login` SET `email`='$email',`password`='$password' WHERE `login_id`='$regid'";
$results2=mysqli_query($con,$sql2);

if($results1 AND $results2){
  header('Location: admin_doc.php?success=Data updated successfully');
}else{
  header('Location: admin_edit.php?error=Data not updated');
}
 }
?>
