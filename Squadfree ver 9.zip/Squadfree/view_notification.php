<?php
include 'database.php';
$email=$_SESSION["email"];


//$sql="select * from comments ORDER BY id DESC limit 5";
//$result=mysqli_query($conn, $sql);//from notification



$sql="SELECT  `REGID` as reg FROM `registration` WHERE  `email`='$email'";
$result=mysqli_query($con,$sql);
$row1 = mysqli_fetch_array($result);
$reg_id = $row1['reg'];
 //echo $reg_id;

 $sql12="SELECT `doc_id` FROM `doctor` WHERE `REGID`='$reg_id'";
 $result12=mysqli_query($con,$sql12);
 $row2 = mysqli_fetch_array($result12);
 $did = $row2['doc_id'];
 //echo $did;

$sql1="SELECT   * FROM `appointment` WHERE `doctor_id`='$did' and `notification`=0 ORDER BY `appoint_id` DESC limit 5 " ;
$results=mysqli_query($con,$sql1);
$count=mysqli_num_rows($results);

$response='';
while($row3=mysqli_fetch_array($results))
{
	$appoint=$row3['appoint_id'];









							 $sql2="SELECT `REGID` as id FROM `appointment` WHERE `doctor_id`='$did' and `appoint_id`='$appoint' ";
							 $result2=mysqli_query($con,$sql2);
							 $row4 = mysqli_fetch_array($result2);
							 $id = $row4['id'];

               $sql="UPDATE `appointment` SET `notification`=1 WHERE `notification`=0 and `doctor_id`='$did' and `REGID`='$id'";
               $result=mysqli_query($con, $sql);//from notification

							 $sql3="SELECT `name` as nam FROM `registration` WHERE `REGID`='$id'";
							 $result3=mysqli_query($con,$sql3);
							 $row = mysqli_fetch_array($result3);
							 $name = $row['nam'];


							 $sql6="SELECT  `appointment_on` as dates FROM `appointment` WHERE `doctor_id`='$did' and `appoint_id`='$appoint'";
							 $result6=mysqli_query($con,$sql6);
							 $row = mysqli_fetch_array($result6);
							 $dates = $row['dates'];




						$sql7="SELECT  `t_id` as tid FROM `appointment` WHERE `doctor_id`='$did' and `appoint_id`='$appoint'";
						$result7=mysqli_query($con,$sql7);
						$row = mysqli_fetch_array($result7);
						$tid = $row['tid'];
						//echo $tid;
						$sql8="SELECT  `time` FROM `time` WHERE `time_id`='$tid'";
						$result8=mysqli_query($con,$sql8);
						$row = mysqli_fetch_array($result8);
						$times = $row['time'];




	$response = $response . "<div class='notification-time'>You have an appointent at " . $times .
	"<div class='notification-subject'>from ". $name . "</div>" .
	"<div class='notification-comment'> on " . $dates  . ".</div>" .
	"</div>";

}
if(!empty($response)) {
	print $response;
  ?>

 <?php
}


?>
