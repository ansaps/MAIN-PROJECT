<!DOCTYPE html>
<?php

include 'database.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />
  <link href="search.css" rel="stylesheet" />
    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">



</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
							<ul class="nav navbar-nav">
								<li class="active"><a href="index.php">Home</a></li>
								<!--<li><a href="#"><input name="search" value="" id="searchText" maxlength="256" aria-label="Search query" autocomplete="off" aria-autocomplete="true" aria-controls="searchSuggestionTable" aria-expanded="false" placeholder="Search" type="text" />
									<input id="searchSubmit" onclick="onSearchSubmit(event)" title="Submit search" value="▶" type="button" /></a></li>-->

								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">VIEW<b class="caret"></b></a>
									<ul class="dropdown-menu">
										<li><a href="admin_doc.php">DOCTOR</a></li>
										<li><a href="admin_pat.php">PATIENT</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">SPECIALIST<b class="caret"></b></a>
									<ul class="dropdown-menu">
										<li><a href="add_specialist.php">ADD</a></li>
										<li><a href="admin_pat.php">VIEW</a></li>
									</ul>
								</li>

								<li><a href="logout.php">Logout</a></li>
							</ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>





<!-- Section: Register.Php -->


      <section id="register" class="home-section text-center">
        <div class="heading-about">
    			<div class="container">
    			<div class="row">
    				<div class="col-lg-8 col-lg-offset-2">
    					<div class="wow bounceInDown" data-wow-delay="0.4s">
    					<div class="section-heading">
    					<h2>Specialist</h2>
    					<i class="fa fa-2x fa-angle-down"></i>

    					</div>
    					</div>
    				</div>
    			</div>
        </div>

        <div class="container">

        <div class="row">
            <div class="col-lg-8">
                <div class="boxed-grey">

                    <form id="register-form" action="" method="post"   role="form" class="contactForm">
                      <?php

                      $sql1="SELECT `Specialized_in` FROM `specialization`";
                      $results=mysqli_query($con,$sql1);
                      while($row=mysqli_fetch_array($results))
                       {
                         ?>
                    <div class="row">


                          <table>
                            <td>

                              <div class="form-group">
                                <input type="text" name="specialization"  class="form-control" id="specialization" value="<?php echo $row['Specialized_in'] ?>" />
                                <div class="validation"></div>
                              </div>

                            </td>
                            <td>
                          <div class="form-group">
                            <button type="submit" class="btn btn-skin pull-right" id="btnContactUs" name="submit">Specialized Doctors</button>
                          </div>
                        </td>
                      </table>



                  </div>
                  <?php } ?>
                    </form>

                </div>
            </div>

         </div>

    		</div>

    	</section>

			<!-- Section: login -->








	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;SquadFREE. All rights reserved.</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js1/validation.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
