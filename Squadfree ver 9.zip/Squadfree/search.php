<!DOCTYPE html>
<?php

include 'database.php';



if(isset($_POST['submit'])){




$email=$_POST["email"];
$password=SHA1($_POST["password"]);
}
?>


<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Squadfree - Free bootstrap 3 one page template</title>
  <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<style>
.home-section-background1{
    position: relative;

    height: 100%;
    background: url(../images/bg/plane.jpg);
    background-size: cover;

}
.header-top-area {
    position:relative;
    width: 100%;
	height:10%;
	margin-top:-5px;
	border:2px solid black;
   z-index:-2;
	background: rgba(0, 0, 0, 0.8);
   	color:black;
}
.tr{
margin:30px;
}
</style>




<!---js--->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap1.js"></script>
<!---js--->
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="css/animate.css" rel="stylesheet" />


    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
  <link href="color/default.css" rel="stylesheet">


</head>


<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
  <!-- Preloader -->
  <div id="preloader">
    <div id="load"></div>
  </div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
      <ul class="nav navbar-nav">

<li><a href="user_profile.php">Profile</a></li>
    <li><a href="doctors_available.php">consult</a></li>


      </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

  <!-- Section: intro -->
    <section id="intro" class="intro">

    <div class="slogan">
      <h2>DOCTOR PATIENT <span class="text_color">PORTAL</span> </h2>
      <h4></h4>
    </div>
    <div class="page-scroll">
      <a href="#login" class="btn btn-circle">
        <i class="fa fa-angle-double-down animated"></i>
      </a>
    </div>
    </section>










<br><br><br>
<center>
<h2>SEARCH YOUR DOCTOR</h2>
</center>


<br><br><br>
		<center>

		 <form class="form-inline navbar-search" method="post" action="#" style="padding-top:5px;">
		 <b>SEARCH</b>
			<input class="form-control" type="text"  placeholder="" style="padding:11px 14px;" name="txtModel">
			<button type="submit" class="btn btn-warning btn-large" style="margin-top:0;color:white;background-color:#333d47;" name="goButton"> GO </button>
		</form>
		</center>


</header>
<br><br><br>
<!-- ======================= -->



        <?php
            //if(isset($_GET['category_id'])){
              //  if(isset($_SESSION['utype'])){
                   // if($_SESSION['utype']==='S'){
                        //$id=$_REQUEST['category_id'];
                        //echo $id;
				if(isset($_POST['goButton']))
{
	$name=$_POST['txtModel'];
	if($name=="")
	{

		    echo "<script>if(confirm(' plz enter your doctor name')){document.location.href='search.php'}else{document.location.href='search.php'};</script>";


	}
	 $sql1=mysqli_query($con,"SELECT * FROM `registration` where `name` like '%$name%' and  `category_id`=1;");
   //$records1=mysqli_fetch_array($sql1);
   //$sql2="SELECT `REGID` as register_id from `registration` where `name` like '%$name%'";
   //$result2=mysqli_query($con,$sql2);
   //$row1 = mysqli_fetch_array($result2);
   //$regid = $row1['register_id'];
   //$regid=$records1['REGID'];
   //$sql3=mysqli_query($con,"SELECT * FROM `doctor` where `REGID`='$regid'");
						$i=0;
                            while($records1=mysqli_fetch_array($sql1)){
								$i++;
								if($i>6){
        ?>

<table>
                                <tr>
		<?php
								}
								else{

		?>
		<center>
      <?php
      // $regid=$records1['REGID'];
       //echo $regid;
      ?>
	<!--<a  style="text-decoration: none; color: black; margin-right:10px" href=<?php //echo "#?reg_id={$records1['REGID']}" ?> ><h4><b><?php echo"{$records1['name']}"; ?></h4></b></a>

                                    <td colspan="2" align="center">

                                    <img src="<?php //echo "{$records1['name']}"; ?>" alt='' width="200" height="200" /><br>
									<b>PRICE:<?php// echo "{$records1['email']}"; ?></b>-->
                  <form name="doctors_available" action="" method="post" role="form" class="contactForm">
                  <div class="container">
                    <div class="row">
                          <div class="col-md-3">
                          <div class="wow bounceInUp" data-wow-delay="0.2s">
                                  <div class="team boxed-grey">
                                      <div class="inner">
                              <h5><?php
                              $regid=$records1['REGID'];
                              //$doc_id=$row['doc_id'];
                              //$sql2="select `REGID` as register_id from `doctor` where `doc_id`='$doc_id'";
                              //$result2=mysqli_query($con,$sql2);
                              //$row1 = mysqli_fetch_array($result2);
                              //$register_id = $row1['register_id'];

                              $sql3="SELECT `name` as name FROM `registration` WHERE `REGID`='$regid'";
                              $result3=mysqli_query($con,$sql3);
                              $row2 = mysqli_fetch_array($result3);
                              $name = $row2['name'];
                              echo $name;

                              ?></h5>
                                          <p class="subtitle"><?php
                                          $sql2="SELECT * FROM `doctor` where `REGID`='$regid'";
                                          $result2=mysqli_query($con,$sql2);
                                          $row = mysqli_fetch_array($result2);
                                          //$regid = $row1['register_id'];
                                          $doc_id=$row['doc_id'];
                                          $sql4="select `specialization_id` as sid from `doctor` where `doc_id`='$doc_id'";
                                          $result4=mysqli_query($con,$sql4);
                                          $row3 = mysqli_fetch_array($result4);
                                          $s_id = $row3['sid'];
                                          $sql5="SELECT `Specialized_in` as sname FROM `specialization` WHERE `Specilization_id`='$s_id'";
                                          $result5=mysqli_query($con,$sql5);
                                          $row4 = mysqli_fetch_array($result5);
                                          $sname = $row4['sname'];
                                          echo $sname;?></p>
                                          <div class="avatar"><img src="<?php echo $row['image'] ?>" alt="display" class="img-responsive img-circle" height="50"  width="100"/>

                                          <input type="hidden" name="doc_id" id="doc_id" value="<?php echo $row['doc_id'] ?>" />


                                          <button type="submit" class="btn btn-skin pull-right" id="btnContactUs" id="book" value="book"  >
                                            <a href="new_allotment.php?id=<?php echo $row['doc_id'];?>">Book</a>
                                                </button><?php
                                                if(isset($_POST["doc_id"])){
                                                  $doc_id=$row['doc_id'];
                                                  //echo $doc_id;
                                                }


                                                ?>

                                          </div>

                                      </div>

                                  </div>
                                  <hr>
                          </div>

                              </div>


                        <?php


                  } ?>

                  </div>

                  </div>

                  </form>
                                           <?php
		                        }}
		?>

</table>
























	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;SquadFREE. All rights reserved.</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
