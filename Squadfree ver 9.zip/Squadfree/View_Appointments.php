<!DOCTYPE html>
<?php

include 'database.php';
//$email=$_REQUEST["email"];
$email=$_SESSION["email"];
$min_date=date('Y-m-d');

//echo $email;

?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>doctor patient portal</title>
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---js--->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap1.js"></script>
<!---js--->
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />


    <!-- Squad theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">





</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

  <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
      <div class="container">
          <div class="navbar-header page-scroll">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                  <i class="fa fa-bars"></i>
              </button>
              <a class="navbar-brand" href="index.html">
                  <h1>DOCTOR PATIENT PORTAL</h1>
              </a>
          </div>

          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
    <ul class="nav navbar-nav">
      <li class="active"><a href="register.php">Home</a></li>
      <!--<li><a href="#"><input name="search" value="" id="searchText" maxlength="256" aria-label="Search query" autocomplete="off" aria-autocomplete="true" aria-controls="searchSuggestionTable" aria-expanded="false" placeholder="Search" type="text" />
        <input id="searchSubmit" onclick="onSearchSubmit(event)" title="Submit search" value="▶" type="button" /></a></li>-->
        <li><a href="profile.php">Profile</a></li>
        <li><a href="change_password_doctor.php">Change Password</a></li>
        <li><a href="edit_profile.php">Edit Profile</a></li>


          <li><a href="#">Appointments</a></li>

       <li><a href="time_alloting.php">Set Time</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
          </div>
          <!-- /.navbar-collapse -->
      </div>
      <!-- /.container -->
  </nav>
  <!--intro -->
      <section id="intro" class="intro">

      <div class="slogan">

        <h2>WELCOME TO <span class="text_color">DOCTOR PATIENT PORTAL</span> </h2>

      </div>
      <div class="page-scroll">
        <a href="#profile" class="btn btn-circle">
          <i class="fa fa-angle-double-down animated"></i>
        </a>
      </div>
    </section>
    <!--/Section: intro -->



<!-- Section: Register.Php -->


      <section id="profile" class="home-section text-center">
        <div class="heading-about">
    			<div class="container">
    			<div class="row">
    				<div class="col-lg-8 col-lg-offset-2">
    					<div class="wow bounceInDown" data-wow-delay="0.4s">
    					<div class="section-heading">
    					<h2>Appointment Made</h2>
    					<i class="fa fa-2x fa-angle-down"></i>

    					</div>
    					</div>
    				</div>
    			</div>
        </div>




<?php

        $sql="SELECT  `REGID` as reg FROM `registration` WHERE  `email`='$email'";
        $result=mysqli_query($con,$sql);
      	$row = mysqli_fetch_array($result);
      	$reg_id = $row['reg'];
         //echo $reg_id;

         $sql12="SELECT `doc_id` FROM `doctor` WHERE `REGID`='$reg_id'";
         $result12=mysqli_query($con,$sql12);
       	 $row = mysqli_fetch_array($result12);
       	 $did = $row['doc_id'];
         //echo $did;

       $sql1="SELECT   * FROM `appointment` WHERE `doctor_id`='$did' and `appointment_on`>='$min_date' ORDER BY `appointment_on` ASC";
       $results=mysqli_query($con,$sql1);
       while($row=mysqli_fetch_array($results))
        {
          $appoint=$row['appoint_id'];


?>


              <div class="container">
                <div class="row">
                  <div class="col-lg-8">
                    <div class="boxed-grey">
                       <table border="1" width="100%" height="auto">
                            <div class="row">
                                 <div class="col-md-6">

                    <tr>
                       <td>
                       <?php
                       $sql2="SELECT `REGID` as id FROM `appointment` WHERE `doctor_id`='$did' and `appoint_id`='$appoint' ";
                       $result2=mysqli_query($con,$sql2);
                     	 $row = mysqli_fetch_array($result2);
                     	 $id = $row['id'];
                       //echo $id;
                       /*$sql2="SELECT `REGID` as id FROM `doctor` WHERE `doc_id`='$id'";
                       $result2=mysqli_query($con,$sql2);
                     	 $row = mysqli_fetch_array($result2);
                     	 $rid = $row['id'];
                       */
                       $sql3="SELECT `name` as nam FROM `registration` WHERE `REGID`='$id'";
                       $result3=mysqli_query($con,$sql3);
                     	 $row = mysqli_fetch_array($result3);
                     	 $name = $row['nam'];
                        ?>
                        <input type="text" name="name"  class="form-control" id="name" value="<?php echo $name; ?>"  />
                        <div class="validation"></div>
                      </td>

                    <td>
                      <?php
                       $sql6="SELECT  `appointment_on` as dates FROM `appointment` WHERE `doctor_id`='$did' and `appoint_id`='$appoint'";
                       $result6=mysqli_query($con,$sql6);
                       $row = mysqli_fetch_array($result6);
                       $dates = $row['dates'];
                      ?>
                        <input type="text" name="date" class="form-control" id="date" value="<?php echo $dates; ?>"  />
                        <div class="validation"></div>
                  </td>
                  <td>
                    <?php
                    $sql7="SELECT  `t_id` as tid FROM `appointment` WHERE `doctor_id`='$did' and `appoint_id`='$appoint'";
                    $result7=mysqli_query($con,$sql7);
                    $row = mysqli_fetch_array($result7);
                    $tid = $row['tid'];
                    //echo $tid;
                    $sql8="SELECT  `time` FROM `time` WHERE `time_id`='$tid'";
                    $result8=mysqli_query($con,$sql8);
                    $row = mysqli_fetch_array($result8);
                    $times = $row['time'];
                    $sql9="SELECT  `meridiem` FROM `time` WHERE `time_id`='$tid'";
                    $result9=mysqli_query($con,$sql9);
                    $row = mysqli_fetch_array($result9);
                    $meridiem = $row['meridiem'];
                    ?>

                        <input type="text" name="time" class="form-control" id="time" value="<?php echo substr($times,0,5); echo " "; echo $meridiem;?>" />
                        <div class="validation"></div>
                  </td>
                  <td>

                        <button type="submit" class="form-control" name="submit" id="address"  value="delete" ><a href="Add_medical.php?id=<?php echo $appoint;?>&did=<?php echo $did; ?>&regid=<?php echo $id;?>&date=<?php echo $dates;?>">Add</a></button>
                        <div class="validation"></div>
                 </td>

                 <td>

                       <button type="submit" class="form-control" name="submit" id="address"  value="delete" ><a href="View_Medical.php?id=<?php echo $appoint;?>&did=<?php echo $did; ?>&regid=<?php echo $id;?>&date=<?php echo $dates;?>">View </a></button>
                       <div class="validation"></div>
                </td>
               </tr>


            </table>
                </div>
            </div>


        </div>
    </div>

 </div>

</div>


<?php   }?>

    	</section>


			<!-- Section: login -->








	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>
					<p>&copy;SquadFREE. All rights reserved.</p>
                    <div class="credits">
                        <!--
                            All the links in the footer should remain intact.
                            You can delete the links only if you purchased the pro version.
                            Licensing information: https://bootstrapmade.com/license/
                            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Squadfree
                        -->
                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
