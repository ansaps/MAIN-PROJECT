<?php
include 'database.php';
$absent_id=$_GET['id'];
$min_date = date('Y-m-d');
$sq="SELECT `date` as dat FROM `absence` WHERE `ab_id`='$absent_id'";
$re=mysqli_query($con,$sq);
$ro=mysqli_fetch_array($re);
echo $date=$ro['dat'];
if($date>=$min_date)
{
  $sql="DELETE FROM `absence` WHERE `ab_id`='$absent_id'";
  $res=mysqli_query($con,$sql);
  echo "<script>document.location.href='absent_view.php';</script>";
}
else {
  $mess = "This leave  on $date cannot be modified";
  echo "<script type='text/javascript'>alert('$mess');document.location.href='absent_view.php';</script>";
}

 ?>
