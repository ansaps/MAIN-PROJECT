<?php
//session_start();
$con=mysqli_connect("localhost","root","","portal");

if(session_status()==PHP_SESSION_NONE)
{
	session_start();
}

if (!$con) {


    die('Not connected : ' . mysql_error());
}

?>
