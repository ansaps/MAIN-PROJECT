<!DOCTYPE html>
<?php

include 'database.php';
$id=$_GET['id'];
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Squadfree - Free bootstrap 3 one page template</title>
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---js--->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap1.js"></script>
<!---js--->
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" />


    <!--  theme CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">






</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <h1>DOCTOR PATIENT PORTAL</h1>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
      <ul class="nav navbar-nav">
    <li class="active"><a href="index.php">Home</a></li>

    <li><a href="doctors_available.php">consult</a></li>
    <li><a href="Appointement.php">book</a></li>
    <li><a href="Appointment _Made.php">Appointment Made</a></li>
    <li><a href="logout.php">Logout</a></li>

      </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	<!-- Section: intro -->
    <section id="intro" class="intro">

		<div class="slogan">
			<h2>DOCTOR PATIENT <span class="text_color">PORTAL</span> </h2>
			<h4></h4>
		</div>
		<div class="page-scroll">
			<a href="#login" class="btn btn-circle">
				<i class="fa fa-angle-double-down animated"></i>
			</a>
		</div>
    </section>
	<!-- /Section: intro -->




<!-- Section: Login-Php -->
	<!-- /Section: login -->
     <center>
      <section id="login" class="home-section text-center">
        <div class="heading-about">
    			<div class="container">
    			<div class="row">
    				<div class="col-lg-8 col-lg-offset-2">
    					<div class="wow bounceInDown" data-wow-delay="0.4s">
    					<div class="section-heading">
    					<h2>Select Slot</h2>
    					<i class="fa fa-2x fa-angle-down"></i>

    					</div>
    					</div>
    				</div>
    			</div>
        </div>

        <div class="container">
          <div class="row">
            <div class="col-lg-2 col-lg-offset-5">
              <hr class="marginbot-50">
            </div>
          </div>

      <?php

      $sql4="SELECT  `time_alloted_from` as start FROM `time_alloting` WHERE `doc_id`='$id'";
      $result6=mysqli_query($con,$sql4);
    	$row = mysqli_fetch_array($result6);
    	$start_time = $row['start'];

      $sql5="SELECT  `alloted_from` as start_meridiem FROM `time_alloting` WHERE `doc_id`='$id'";
      $result6=mysqli_query($con,$sql5);
      $row = mysqli_fetch_array($result6);
      $start_meridiem = $row['start_meridiem'];

      $sql6="SELECT  `time_alloted_to` as stop FROM `time_alloting` WHERE `doc_id`='$id'";
      $result7=mysqli_query($con,$sql6);
    	$row = mysqli_fetch_array($result7);
    	$stop_time = $row['stop'];
      $sql7="SELECT  `aloted_to` as stop_meridiem FROM `time_alloting` WHERE `doc_id`='$id'";
      $result8=mysqli_query($con,$sql7);
      $row = mysqli_fetch_array($result8);
      $stop_meridiem = $row['stop_meridiem'];

      $sql8="SELECT `time_id` as beg  FROM `time` WHERE `time`='$start_time' and  `meridiem`='$start_meridiem'";
      $result9=mysqli_query($con,$sql8);
    	$row = mysqli_fetch_array($result9);
    	$beg = $row['beg'];

      $sql9="SELECT `time_id` as last  FROM `time` WHERE `time`='$stop_time' and  `meridiem`='$stop_meridiem'";
      $result10=mysqli_query($con,$sql9);
      $row = mysqli_fetch_array($result10);
      $last = $row['last'];

      $i=0;
      for($i=$beg;$i<=$last;$i++)
      {
        $sql1="SELECT  `time` as tim FROM `time` WHERE `time_id`='$i'";
        $result1=mysqli_query($con,$sql1);
        $row = mysqli_fetch_array($result1);
        $time = $row['tim'];
        //echo $time;
        $sql2="SELECT  `meridiem` as mer FROM `time` WHERE `time_id`='$i'";
        $result2=mysqli_query($con,$sql2);
        $row = mysqli_fetch_array($result2);
        $merid = $row['mer'];
      ?>
      <form name="select_time" action="" method="post">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
      				<div class="wow bounceInUp" data-wow-delay="0.2s">
                      <div class="team boxed-grey">
                          <div class="inner">
                            <table border=0px>
                              <tr>
                                <td>
                            <input type="text"  class="form-control" name="time" id="time" value="<?php echo $time; ?>" >

                            </td>
                            <td>
                           <input type="text" class="form-control" name="meridiem" id="meridiem" value="<?php echo $merid; ?>">
                        </td>
                      </tr>
                    </table>
                    <?php
                    $sql2="SELECT `time_id` as times FROM `time` WHERE `time`='$time' and `meridiem`='$merid'";
                    $result2=mysqli_query($con,$sql2);
                    $row = mysqli_fetch_array($result2);
                    $tim = $row['times'];

                    ?>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-skin pull-right" id="btnContactUs"  name="submit"  value="<?php echo $tim; ?>">
                        <a href="booked.php?id=<?php echo $id; ?>&time=<?php echo $tim; ?>">Select</a>
                        </button>
                    </div>




                              </div>

                          </div>

                      </div>
                      <hr>
      				</div>




      			<?php


      } ?>

        </div>
      </div>
      </div>
      <form>
          </div>

    	</section>
   </center>
			<!-- Section: login -->








	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="wow shake" data-wow-delay="0.4s">
					<div class="page-scroll marginbot-30">
						<a href="#intro" id="totop" class="btn btn-circle">
							<i class="fa fa-angle-double-up animated"></i>
						</a>
					</div>
					</div>

                    <div class="credits">

                        <a href="https://bootstrapmade.com/free-one-page-bootstrap-themes-website-templates/">One Page Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
				</div>
			</div>
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>

</body>

</html>
